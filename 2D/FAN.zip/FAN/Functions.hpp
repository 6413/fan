#pragma once
#include <FAN/Math.hpp>
#include <FAN/Graphics.hpp>
#include <map>