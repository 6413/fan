#pragma once

#include <vector>
#include "FAN/Texture.hpp"

char* LoadBMP(const char* path, Object& object);