#include "Input.hpp"

//namespace CursorNamespace {
//	__Vec2<int> cursorPos;
//}
//
//namespace WindowNamespace {
//	__Vec2<int> windowSize;
//}
//
//namespace Input {
//	bool key[1024];
//	bool readchar;
//	std::string characters;
//	bool action[348];
//	bool released[1024];
//}