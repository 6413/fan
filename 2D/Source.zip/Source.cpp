#include <iostream>
#include <FAN/Graphics.hpp>
#include <FAN/DBT.hpp>
#include <vector>
#include <chrono>

struct Particle {
	float life_time;
	decltype(std::chrono::high_resolution_clock::now()) time;
	bool display;
	Vec2 particle_speed;
};

class Timer {
public:
	void start(int time) {
		this->timer = std::chrono::high_resolution_clock::now();
		this->time = time;
	}
	void restart() {
		this->timer = std::chrono::high_resolution_clock::now();
	}
	bool finished() {
		return std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::high_resolution_clock::now() - timer).count() >= time;
	}
private:
	decltype(std::chrono::high_resolution_clock::now()) timer;
	int time;
};

int main() {
	glfwSetErrorCallback(GlfwErrorCallback);
	if (!glfwInit()) {
		printf("GLFW ded\n");
		return 0;
	}
	WindowInit();
	Main _Main;
	_Main.shader.Use();
	glfwSetKeyCallback(window, KeyCallback);
	glfwSetCharCallback(window, CharacterCallback);
	glfwSetScrollCallback(window, ScrollCallback);
	glfwSetWindowUserPointer(window, &_Main.camera);
	glfwSetCursorPosCallback(window, CursorPositionCallback);
	glfwSetMouseButtonCallback(window, MouseButtonCallback);
	glfwSetFramebufferSizeCallback(window, FrameSizeCallback);

	using namespace std::chrono;

	constexpr auto particle_amount = 1000;
	constexpr auto particle_speed = 1000;
	constexpr auto life_time = 500;
		
	constexpr auto size = blockSize / 2;

	Square particles(particle_amount, Vec2(size), Vec2(size), Color(1, 0, 0, 1));
	Alloc<Particle> particle;

	for (int i = 0; i < particle_amount; i++) {
		float theta = 2.0f * 3.1415926f * float(i) / float(10);
		float x = particle_speed * cosf(theta);
		float y = particle_speed * sinf(theta);
		particle.push_back({ life_time, decltype(std::chrono::high_resolution_clock::now())(), 0, Vec2(x, y) });

	}
//	particles.break_queue();

	size_t particleIndex = 0;

	Timer timer;
	timer.start(0);

	auto time = high_resolution_clock::now();

	Square sq(Vec2(200.f), Vec2(64), Color(0, 1, 0));

	while (!glfwWindowShouldClose(window)) {
		glfwPollEvents();
		glClearColor(0, 0, 0, 1);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		particleIndex %= particle_amount;

		//if (KeyPressA(GLFW_MOUSE_BUTTON_LEFT)) {
		//	sq.get_position(0).print();
		//	sq.set_position(0, sq.get_position(0) + Vec2(64));
		//	sq.get_position(0).print();
		//}

		if (KeyPress(GLFW_MOUSE_BUTTON_LEFT) && timer.finished()) {
			sq.set_position(0, cursorPos);
			/*if (!particle[particleIndex].time.time_since_epoch().count()) {
				particles.set_position(particleIndex, cursorPos);
				particle[particleIndex].time = high_resolution_clock::now();
				particle[particleIndex].display = true;
				particleIndex++;
			}
			timer.restart();*/
		}

		//square.rotate(0, duration_cast<milliseconds>(high_resolution_clock::now() - time).count() / 2);
		//square.rotate(1, duration_cast<milliseconds>(high_resolution_clock::now() - time).count() / 2);

		for (int i = 0; i < particles.amount(); i++) {
			if (!particle[i].display) {
				continue;
			}
			if (duration_cast<milliseconds>(high_resolution_clock::now() - particle[i].time).count() >= particle[i].life_time) {
				particles.set_position(i, Vec2(-blockSize), true);
				particle[i].display = false;
				particle[i].time = decltype(high_resolution_clock::now())();
				continue;
			}
			Color color = particles.get_color(i);
			particles.set_color(i, Color(color.r, color.g, (float)duration_cast<milliseconds>((high_resolution_clock::now() - particle[i].time)).count() / 1000.f, (particle[i].life_time - (float)duration_cast<milliseconds>((high_resolution_clock::now() - particle[i].time)).count() / 1000.f) / particle[i].life_time), true);
			//printf("before pos %f\n", particles.get_position(i).x);
			particles.set_position(i, particles.get_position(i) + Vec2(particle[i].particle_speed.x * deltaTime, particle[i].particle_speed.y * deltaTime), true);
			//printf("pos %f\n", particles.get_position(i).x);
		}

		sq.draw();
		particles.break_queue();
		particles.draw();

		if (KeyPress(GLFW_KEY_ESCAPE)) {
			glfwSetWindowShouldClose(window, true);
		}

		GetFps();
		glfwSwapBuffers(window);
		KeysReset();
	}
}