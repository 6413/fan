#include <iostream>
#include <FAN/Graphics.hpp>
#include <FAN/DBT.hpp>
#include <Windows.h>

size_t _2D1D() {
	return (int(cursorPos.x / blockSize)) + int(cursorPos.y / blockSize) * (windowSize.y / blockSize);
}

size_t _2D1D(Vec2 pos) {
	return (int(floor(pos.x / blockSize))) + int(floor(pos.y / blockSize)) * (windowSize.y / blockSize);
}

#define movement_speed 10000000

int main() {
	glfwSetErrorCallback(GlfwErrorCallback);
	if (!glfwInit()) {
		printf("GLFW ded\n");
		return 0;
	}
	GLFWwindow* window;
	WindowInit(window);
	Main _Main;
	_Main.shader.Use();
	glfwSetKeyCallback(window, KeyCallback);
	glfwSetCharCallback(window, CharacterCallback);
	glfwSetMouseButtonCallback(window, MouseButtonCallback);
	glfwSetFramebufferSizeCallback(window, FrameSizeCallback);
	glfwSetCursorPosCallback(window, CursorPositionCallback);

	__Vec2<int> view(windowSize.x / blockSize, windowSize.y / blockSize);
	Square grid(&_Main.camera);

	for (int y = 0; y < view.y; y++) {
		for (int x = 0; x < view.x; x++) {
			grid.push_back(Vec2(x * blockSize, y * blockSize), Vec2(blockSize), Color(0, 0, 0, 1));
		}
	}

	Alloc<bool> wall;

	for (int y = 0; y < view.x * view.y; y++) {
		wall.push_back(false);
	}

	Square collidable(&_Main.camera, Vec2(), Vec2(blockSize), Color(.415, 0.05, .67, 1));

	while (!glfwWindowShouldClose(window)) {
		glfwPollEvents();
		glClearColor(0, 0, 0, 1);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		if (KeyPressA(GLFW_MOUSE_BUTTON_RIGHT)) {
			Color newColor;
			newColor.r = (unsigned int)grid.get_color(_2D1D()).r ^ (unsigned int)1;
			newColor.a = 1;
			wall[_2D1D()] = !wall[_2D1D()];
			grid.set_color(_2D1D(), newColor);
		}

		if (KeyPress(GLFW_MOUSE_BUTTON_LEFT)) {
			//Vec2 floored(floor(cursorPos.x / blockSize) * blockSize, floor(cursorPos.y / blockSize) * blockSize);
			collidable.set_position(0, cursorPos);
		}

		Vec2 position = collidable.get_position(0);
		if (KeyPress(GLFW_KEY_W)) {
			int max_movement = -1;
			if (position.y <= 0) {
				collidable.set_position(0, Vec2(collidable.get_position(0).x, 0));
				goto skipw;
			}
			for (int i = 0; i < movement_speed / blockSize; i++) {
				if (wall[_2D1D(position - Vec2(0, i)) % (view.x * view.y)] ||
					wall[_2D1D(position - Vec2(-blockSize, i)) % (view.x * view.y)]) {
					if (position.y - i <= 0) {
						collidable.set_position(0, Vec2(collidable.get_position(0).x, 0));
						goto skipw;
					}
					if (!i) {
						goto skipw;
					}
					max_movement = i;
					break;
				}
			}
			if (max_movement != -1) {
				position.y -= max_movement;
			}
			else {
				position.y -= movement_speed * deltaTime;
			}
			collidable.set_position(0, position);
		skipw:;
		}

		if (KeyPress(GLFW_KEY_A)) {
			int max_movement = -1;
			if (position.x <= 0) {
				collidable.set_position(0, Vec2(0, collidable.get_position(0).y));
				goto skipa;
			}
			for (int i = 0; i < movement_speed / blockSize; i++) {
				if (wall[_2D1D(position - Vec2(i, 0)) % (view.x * view.y)] ||
					wall[_2D1D(position - Vec2(i, -blockSize)) % (view.x * view.y)]) {
					if (position.x - i <= 0) {
						collidable.set_position(0, Vec2(0, collidable.get_position(0).y));
						goto skipa;
					}
					if (!i) {
						goto skipa;
					}
					max_movement = i;
					break;
				}
			}
			if (max_movement != -1) {
				position.x -= max_movement;
			}
			else {
				position.x -= movement_speed * deltaTime;
			}
			collidable.set_position(0, position);
		skipa:;
		}
		if (KeyPress(GLFW_KEY_S)) {
			int max_movement = -1;
			if (position.y + blockSize >= windowSize.y) {
				//printf("outside\n");
				collidable.set_position(0, Vec2(collidable.get_position(0).x, windowSize.y - blockSize));
				goto skips;
			}
			for (int i = 0; i < movement_speed / blockSize; i++) {
				if (wall[_2D1D(position + Vec2(0, i)) % (view.x * view.y)] ||
					wall[_2D1D(position + Vec2(blockSize, i)) % (view.x * view.y)]) {
					if (position.y + i + blockSize >= windowSize.y) {
						collidable.set_position(0, Vec2(collidable.get_position(0).x, windowSize.y - blockSize));
						goto skips;
					}
					if (!i) {
						goto skips;
					}
					max_movement = i - blockSize;
					break;
				}
			}
			if (max_movement != -1) {
				position.y += max_movement;
			}
			else {
				position.y += movement_speed * deltaTime;
			}
			collidable.set_position(0, position);
		skips:;
		}
		if (KeyPress(GLFW_KEY_D)) {
			int max_movement = -1;
			if (position.x + blockSize >= 0) {
				collidable.set_position(0, Vec2(windowSize.x - blockSize, collidable.get_position(0).y));
				goto skipd;
			}
			for (int i = 0; i < movement_speed / blockSize; i++) {
				if (wall[_2D1D(position + Vec2(i, 0)) % (view.x * view.y)] ||
					wall[_2D1D(position + Vec2(i, blockSize)) % (view.x * view.y)]) {
				/*	if (position.x + i - blockSize >= windowSize.x) {
						collidable.set_position(0, Vec2(windowSize.x - blockSize, collidable.get_position(0).y));
						goto skipd;
					}*/
					if (!i) {
						goto skipd;
					}
					max_movement = i - blockSize;
					break;
				}
			}
			if (max_movement != -1) {
				position.x += max_movement;
			}
			else {
				position.x += movement_speed * deltaTime;
			}
			collidable.set_position(0, position);
		skipd:;
		}


		collidable.draw();
		grid.draw();

		if (KeyPress(GLFW_KEY_ESCAPE)) {
			glfwSetWindowShouldClose(window, true);
		}

		GetFps();
		glfwSwapBuffers(window);
		KeysReset();
	}
}