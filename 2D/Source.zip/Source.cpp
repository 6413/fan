#include <iostream>
#include <FAN/Texture.hpp>
#include <FAN/DBT.hpp>

int main() {
	dbt<int> db;
	int key = 5;
	db.push((unsigned char*)&key, sizeof(key) * 8, 10);
	printf("%d\n", db.search((unsigned char*)&key, sizeof(key) * 8));
	db.nodes.free_to_max();
	getchar();
	//glfwSetErrorCallback(GlfwErrorCallback);
	//if (!glfwInit()) {
	//	printf("GLFW ded\n");
	//	return 0;
	//}
	//GLFWwindow* window;
	//WindowInit(window);
	//Main _Main;
	//_Main.shader.Use();
	//glfwSetKeyCallback(window, KeyCallback);
	//glfwSetCharCallback(window, CharacterCallback);
	//glfwSetMouseButtonCallback(window, MouseButtonCallback);
	//glfwSetFramebufferSizeCallback(window, FrameSizeCallback);
	//glfwSetCursorPosCallback(window, CursorPositionCallback);

	//Line line(&_Main.camera, Mat2x2(Vec2(), windowSize), Color(0, 1, 0, 1));

	//while (!glfwWindowShouldClose(window)) {
	//	glfwPollEvents();
	//	glClearColor(0, 0, 0, 1);
	//	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	//	//line.draw();

	//	GetFps();
	//	glfwSwapBuffers(window);
	//	KeysReset();
	//}
}