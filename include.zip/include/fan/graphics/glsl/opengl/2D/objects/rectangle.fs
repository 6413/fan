R"(
#version 130

in vec4 instance_color;

out vec4 color;

void main() {
    color = instance_color;
}
)"