void builder_t::open(pile_t* pile) {

  #include "rectangle_sized_text_button/open.h"

  #include "text_renderer_clickable/open.h"
}