#pragma once

#ifndef WED_set_debug_InvalidCharacterAccess
	#define WED_set_debug_InvalidCharacterAccess 0
#endif
#ifndef WED_set_debug_InvalidLineAccess
	#define WED_set_debug_InvalidLineAccess 0
#endif
#ifndef WED_set_debug_InvalidCursorAccess
	#define WED_set_debug_InvalidCursorAccess 0
#endif

#include _FAN_PATH(fed/internal/types.h)
#include _FAN_PATH(fed/internal/private.h)
#include _FAN_PATH(fed/internal/public.h)
