hitbox.open(&pile->context);
hitbox.enable_draw(&pile->context);
hitbox.bind_matrices(&pile->context, &pile->editor.gui_matrices);