button.open(&pile->window, &pile->context);
button.enable_draw(&pile->window, &pile->context);
button.bind_matrices(&pile->context, &pile->editor.gui_matrices);