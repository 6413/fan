void builder_t::open(pile_t* pile) {

  #include _FAN_PATH(graphics/gui/fgm/includes/open.h)
}