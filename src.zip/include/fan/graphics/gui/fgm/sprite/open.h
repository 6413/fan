sprite.open(&pile->context);
sprite.enable_draw(&pile->context);
sprite.bind_matrices(&pile->context, &pile->editor.gui_matrices);