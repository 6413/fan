#include _FAN_PATH(graphics/gui/fgm/sprite/resize.h)
#include _FAN_PATH(graphics/gui/fgm/text_renderer/resize.h)
#include _FAN_PATH(graphics/gui/fgm/hitbox/resize.h)
#include _FAN_PATH(graphics/gui/fgm/button/resize.h)