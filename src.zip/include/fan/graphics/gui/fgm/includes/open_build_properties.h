#include _FAN_PATH(graphics/gui/fgm/sprite/open_build_properties.h)
#include _FAN_PATH(graphics/gui/fgm/text_renderer/open_build_properties.h)
#include _FAN_PATH(graphics/gui/fgm/hitbox/open_build_properties.h)
#include _FAN_PATH(graphics/gui/fgm/button/open_build_properties.h)