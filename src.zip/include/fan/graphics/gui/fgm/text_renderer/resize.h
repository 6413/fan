case builder_draw_type_t::text_renderer: {
  pile->editor.update_resize_rectangles(pile);
  break;
}