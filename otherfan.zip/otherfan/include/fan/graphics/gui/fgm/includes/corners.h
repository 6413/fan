#include _FAN_PATH(graphics/gui/fgm/sprite/corners.h)
#include _FAN_PATH(graphics/gui/fgm/text_renderer/corners.h)
#include _FAN_PATH(graphics/gui/fgm/hitbox/corners.h)
#include _FAN_PATH(graphics/gui/fgm/button/corners.h)