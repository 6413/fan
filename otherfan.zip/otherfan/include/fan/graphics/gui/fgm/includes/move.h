#include _FAN_PATH(graphics/gui/fgm/sprite/move.h)
#include _FAN_PATH(graphics/gui/fgm/text_renderer/move.h)
#include _FAN_PATH(graphics/gui/fgm/hitbox/move.h)
#include _FAN_PATH(graphics/gui/fgm/button/move.h)