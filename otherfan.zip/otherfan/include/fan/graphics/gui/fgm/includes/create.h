#include _FAN_PATH(graphics/gui/fgm/sprite/create.h)
#include _FAN_PATH(graphics/gui/fgm/text_renderer/create.h)
#include _FAN_PATH(graphics/gui/fgm/hitbox/create.h)
#include _FAN_PATH(graphics/gui/fgm/button/create.h)