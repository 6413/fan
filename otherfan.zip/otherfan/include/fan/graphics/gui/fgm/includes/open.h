#include _FAN_PATH(graphics/gui/fgm/sprite/open.h)
#include _FAN_PATH(graphics/gui/fgm/text_renderer/open.h)
#include _FAN_PATH(graphics/gui/fgm/hitbox/open.h)
#include _FAN_PATH(graphics/gui/fgm/button/open.h)