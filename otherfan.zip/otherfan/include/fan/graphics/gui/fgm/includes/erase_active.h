#include _FAN_PATH(graphics/gui/fgm/sprite/erase_active.h)
#include _FAN_PATH(graphics/gui/fgm/text_renderer/erase_active.h)
#include _FAN_PATH(graphics/gui/fgm/hitbox/erase_active.h)
#include _FAN_PATH(graphics/gui/fgm/button/erase_active.h)