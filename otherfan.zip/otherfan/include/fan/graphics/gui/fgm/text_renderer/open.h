tr.open(&pile->context);
tr.enable_draw(&pile->context);
tr.bind_matrices(&pile->context, &pile->editor.gui_matrices);