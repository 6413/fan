var searchData=
[
  ['axes',['axes',['../structGLFWgamepadstate.html#a8b2c8939b1d31458de5359998375c189',1,'GLFWgamepadstate']]]
];
