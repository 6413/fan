#include <iostream>
#include <FAN/Graphics.hpp>
#include <FAN/DBT.hpp>
#include <vector>
#include <chrono>
#include <FAN/Bmp.hpp>

int main() {
	glfwSetErrorCallback(GlfwErrorCallback);
	if (!glfwInit()) {
		printf("GLFW ded\n");
		return 0;
	}
	WindowInit();
	Main _Main;
	_Main.shader.Use();
	glfwSetKeyCallback(window, KeyCallback);
	glfwSetCharCallback(window, CharacterCallback);
	glfwSetScrollCallback(window, ScrollCallback);
	glfwSetWindowUserPointer(window, &_Main.camera);
	glfwSetCursorPosCallback(window, CursorPositionCallback);
	glfwSetMouseButtonCallback(window, MouseButtonCallback);
	glfwSetFramebufferSizeCallback(window, FrameSizeCallback);
	unsigned char pixels[16 * 16 * 4];
	memset(pixels, 0xff, sizeof(pixels));


	Sprite sd("poon.bmp", Vec2(0, windowSize.y - 500), Vec2(100000, 100000));

	//GLFWimage image;
	////image.pixels = (unsigned char*)LoadBMP("picture.bmp", sd.get_texture());
	//image.width = 100;
	//image.height = 100;

//	GLFWcursor* cursor = glfwCreateCursor(&image, 0, 0);
	//glfwSetCursor(window, cursor);

	//Square mycar(Vec2(900 / 2), Vec2(64), Color(1, 0, 0, 1));

	//mycar.free_to_max();

	//Square sq(1000000, Vec2(20), Vec2(20), Color(1, 0, 0));

	//sq.free_to_max();

	while (!glfwWindowShouldClose(window)) {
		glfwPollEvents();
		glClearColor(0, 0, 0, 1);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		sd.Draw();


		if (KeyPress(GLFW_KEY_ESCAPE)) {
			glfwSetWindowShouldClose(window, true);
		}

		GetFps();
		glfwSwapBuffers(window);
		KeysReset();
	}
	//glfwDestroyCursor(cursor);
}