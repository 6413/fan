#pragma once
#include "Vectors.hpp"

void GetFps();

namespace Settings {
	extern float deltaTime;
}