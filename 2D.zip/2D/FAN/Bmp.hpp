#pragma once

#include "FAN/Graphics.hpp"

char* LoadBMP(const char* path, Texture& object);