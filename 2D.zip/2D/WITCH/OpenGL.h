#ifndef WITCH_OpenGL
#define WITCH_OpenGL

#include <stdio.h>
#include <GLFW/glfw3.h>
#define GLEW_STATIC
#include <GL/glew.h>
#include <WITCH/Types.h>
#include <WITCH/Alloc.h>
#include <WITCH/FIO.h>
#include <WITCH/Math.h>

#ifndef GL_UNSIGNED_INT_8_8_8_8
#define GL_UNSIGNED_INT_8_8_8_8 0x8035
#endif

typedef struct{
	T_uic iInfo;
}LT_GLTextureHeader;
#define LDC_GLTextureHeader(M_) (LDC_WITCH(LT_GLTextureHeader){M_})

typedef struct{
	T_uic x, y, Bit, Alpha:1;
}LT_GLTextureProt;

typedef struct{
	LT_GLTextureHeader Header;
	LT_Alloc Info, Tex;
}LT_GLTexture;
#define LDC_GLTexture (LDC_WITCH(LT_GLTexture){LDC_GLTextureHeader(0), LDC_Alloc(sizeof(LT_GLTextureProt)), LDC_Alloc(sizeof(GLuint))})

#define LDF_GLInTexture(M_) LF_GLInTexture((T_ptr)M_)
LT_GLTexture LF_GLInTexture(T_ptr path){
	LT_File File = LDF_FileReadAll(path);
	if(!File.Data){
		fprintf(stderr, "Failed to open texture file: %s\n", path);
		return LDC_GLTexture;
	}
	if(File.Size < sizeof(LT_GLTextureHeader)){
		fprintf(stderr, "Texture file size is smaller than header: %s\n", path);
		if(File.Size)
			free(File.Data);
		return LDC_GLTexture;
	}
	LT_GLTexture RET = LDC_GLTexture;
	RET.Header = *(LT_GLTextureHeader *)File.Data;
	if((File.Size - sizeof(LT_GLTextureHeader)) < (RET.Header.iInfo * sizeof(LT_GLTextureProt))){
		fprintf(stderr, "Texture.Header.iInfo is %u but File.Size is %u, file: %s\n", RET.Header.iInfo, File.Size, path);
		free(File.Data);
		return LDC_GLTexture;
	}
	RET.Info.Current = RET.Header.iInfo;
	LDF_HandleAlloc(&RET.Info);
	{T_ui i0 = 0;
		{T_ui i = 0;
		for(; i < RET.Header.iInfo; i++){
			((LT_GLTextureProt *)RET.Info.ptr)[i] = *(LT_GLTextureProt *)(File.Data + sizeof(LT_GLTextureHeader) + (i * sizeof(LT_GLTextureProt)));
			i0 += ((LT_GLTextureProt *)RET.Info.ptr)[i].x * ((LT_GLTextureProt *)RET.Info.ptr)[i].y * ((LT_GLTextureProt *)RET.Info.ptr)[i].Bit / 8;
		}}
		if((File.Size - sizeof(LT_GLTextureHeader)) - (RET.Header.iInfo * sizeof(LT_GLTextureProt)) < i0){
			fprintf(stderr, "Texture file image data have to be %u but data size is %u, file: %s\n", i0, (File.Size - sizeof(LT_GLTextureHeader)) - (RET.Header.iInfo * sizeof(LT_GLTextureProt)), path);
			LF_FreePTR(File.Data);
			LF_FreePTR(RET.Info.ptr);
			return LDC_GLTexture;
		}
	}
	RET.Tex.Current = RET.Header.iInfo;
	LDF_HandleAlloc(&RET.Tex);
	glGenTextures(RET.Header.iInfo, (GLuint *)RET.Tex.ptr);
	{T_ui i = 0, iData = sizeof(LT_GLTextureHeader) + (RET.Header.iInfo * sizeof(LT_GLTextureProt));
	for(; i < RET.Header.iInfo; i++){
		glBindTexture(GL_TEXTURE_2D, ((GLuint *)RET.Tex.ptr)[i]);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, ((LT_GLTextureProt *)RET.Info.ptr)[i].x, ((LT_GLTextureProt *)RET.Info.ptr)[i].y, 0, GL_RGBA, GL_UNSIGNED_INT_8_8_8_8, File.Data + iData);
		iData += 4 * ((LT_GLTextureProt *)RET.Info.ptr)[i].x * ((LT_GLTextureProt *)RET.Info.ptr)[i].y;
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	}}
	return RET;
}

void LF_GLViewOrtho(T_2si start, T_2si end){
	glViewport(start.x[0], start.x[1], end.x[0], end.x[1]);
	glOrtho(start.x[0], end.x[0], end.x[1], start.x[1], 0, 1);
}

void LF_GLTranslate2(T_2f x){
	#if D_ptrsize == 32
		glTranslatef(x.x[0], x.x[1], 0);
	#elif D_ptrsize == 64
		glTranslated(x.x[0], x.x[1], 0);
	#endif
}

void LF_GLRotate3(T_f Rate, T_f xRotate, T_f yRotate, T_f zRotate){
	#if D_ptrsize == 32
		glRotatef(Rate, xRotate, yRotate, zRotate);
	#elif D_ptrsize == 64
		glRotated(Rate, xRotate, yRotate, zRotate);
	#endif
}

void LF_GLVertex2(T_2f x){
	#if D_ptrsize == 32
		glVertex2f(x.x[0], x.x[1]);
	#elif D_ptrsize == 64
		glVertex2d(x.x[0], x.x[1]);
	#endif
}

void LF_GLColor3(T_3f Color){
	#if D_ptrsize == 32
		glColor3f(Color.x[0], Color.x[1], Color.x[2]);
	#elif D_ptrsize == 64
		glColor3d(Color.x[0], Color.x[1], Color.x[2]);
	#endif
}

void LF_GLColor4(T_4f Color){
	#if D_ptrsize == 32
		glColor4f(Color.x[0], Color.x[1], Color.x[2], Color.x[3]);
	#elif D_ptrsize == 64
		glColor4d(Color.x[0], Color.x[1], Color.x[2], Color.x[3]);
	#endif
}

void LF_GLDP(T_2f x){
	glBegin(GL_POINTS);
	LF_GLVertex2(x);
	glEnd();
}

void LF_GLDPS(T_2f x, T_f Size){
	glPointSize(Size);
	glBegin(GL_POINTS);
	LF_GLVertex2(x);
	glEnd();
}
	
void LF_GLDL(T_2f2 x){
	glBegin(GL_LINES);
	LF_GLVertex2(x.x[0]);
	LF_GLVertex2(x.x[1]);
	glEnd();
}

void LF_GLDT(T_2f3 x){
	glBegin(GL_TRIANGLES);
	LF_GLVertex2(x.x[0]);
	LF_GLVertex2(x.x[1]);
	LF_GLVertex2(x.x[2]);
	glEnd();
}

void LF_GLDQ(T_2f4 x){
	glBegin(GL_QUADS);
	LF_GLVertex2(x.x[0]);
	LF_GLVertex2(x.x[1]);
	LF_GLVertex2(x.x[2]);
	LF_GLVertex2(x.x[3]);
	glEnd();
}

void LF_GLDS(T_2f2 x){
	glBegin(GL_QUADS);
	LF_GLVertex2(DC_2f(x.x[0].x[0], x.x[0].x[1]));
	LF_GLVertex2(DC_2f(x.x[1].x[0], x.x[0].x[1]));
	LF_GLVertex2(DC_2f(x.x[1].x[0], x.x[1].x[1]));
	LF_GLVertex2(DC_2f(x.x[0].x[0], x.x[1].x[1]));
	glEnd();
}

void LF_GLDSPointC(T_2f2 x, T_4f InitColor, T_4f Color){
	glBegin(GL_QUADS);
	LF_GLColor4(InitColor);
	LF_GLVertex2(DC_2f(x.x[0].x[0], x.x[0].x[1]));
	LF_GLColor4(Color);
	LF_GLVertex2(DC_2f(x.x[1].x[0], x.x[0].x[1]));
	LF_GLVertex2(DC_2f(x.x[1].x[0], x.x[1].x[1]));
	LF_GLVertex2(DC_2f(x.x[0].x[0], x.x[1].x[1]));
	glEnd();
}

void LF_GLDST(T_2f2 x, GLuint y, T_f Repeat){
	T_f RepeatX = (x.x[1].x[0] - x.x[0].x[0]) / Repeat;
	T_f RepeatY = (x.x[1].x[1] - x.x[0].x[1]) / Repeat;
	LF_GLColor3(DC_3f(1, 1, 1));
	glBindTexture(GL_TEXTURE_2D, y);
	glEnable(GL_TEXTURE_2D);
	glBegin(GL_QUADS);
	glTexCoord2f(0, RepeatY);
	LF_GLVertex2(DC_2f(x.x[0].x[0], x.x[0].x[1]));
	glTexCoord2f(RepeatX, RepeatY);
	LF_GLVertex2(DC_2f(x.x[1].x[0], x.x[0].x[1]));
	glTexCoord2f(RepeatX, 0);
	LF_GLVertex2(DC_2f(x.x[1].x[0], x.x[1].x[1]));
	glTexCoord2f(0, 0);
	LF_GLVertex2(DC_2f(x.x[0].x[0], x.x[1].x[1]));
	glEnd();
	glDisable(GL_TEXTURE_2D);
}

void LF_GLPOLight(T_2f Pos, T_f Size, T_4f srcLight, T_4f dstLight){
	T_2f2 Square;
	Square.x[0] = Pos;
	Square.x[1] = OPR_2fP2f(Pos, DC_2f(Size, Size));
	LF_GLDSPointC(Square, srcLight, dstLight);
	Square.x[1] = OPR_2fP2f(Pos, DC_2f(-Size, Size));
	LF_GLDSPointC(Square, srcLight, dstLight);
	Square.x[1] = OPR_2fP2f(Pos, DC_2f(-Size, -Size));
	LF_GLDSPointC(Square, srcLight, dstLight);
	Square.x[1] = OPR_2fP2f(Pos, DC_2f(Size, -Size));
	LF_GLDSPointC(Square, srcLight, dstLight);
}

typedef struct{
	T_2ui Size;
	T_ptr Data;
}LT_GLFont;
#define LDC_GLFont(M_0, M_1) (LDC_WITCH(LT_GLFont){M_1, LDF_FileReadAll(M_0)})

void LF_GLCharacter(LT_GLFont Font, T_3f Color, T_2f Coordinate, T_ui Character){
	LF_GLColor3(Color);
	glRasterPos2i(Coordinate.x[0], Coordinate.x[1]);
	glBitmap(Font.Size.x[0], Font.Size.x[1], 0, 0, 0, 0, Font.Data + (Character * (((Font.Size.x[0] / 8) + ((Font.Size.x[0] % 8) > 0)) * Font.Size.x[1])));
}
#define LDF_GLSCharacter(x, y, z) LF_Character(x, DC_3f(1, 1, 1), y, z)

void LF_GLString(LT_GLFont Font, T_3f Color, T_2f Coordinate, T_uia *String, T_ui Size){
	while(Size--){
		LF_GLCharacter(Font, Color, Coordinate, *String);
		Coordinate.x[0] += Font.Size.x[0] + 1;
		*String++;
	}
}
#define LDF_GLSString(x, y, z) LF_GLString(x, DC_3f(1, 1, 1), y, z, FL_StringSize(z))

#endif
