#ifndef WITCH_Network
#define WITCH_Network

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>

#include <WITCH/Types.h>
#include <WITCH/Memory.h>
#include <WITCH/DBT.h>

#define LDC_NETtcpS(M_port) LT_NETtcpS
typedef struct{
	int fd;
}LT_NETtcpS;

#endif 
