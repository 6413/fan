/* Dynamic Binary Tree */

#ifndef WITCH_DBT
#define WITCH_DBT

#include <WITCH/Types.h>
#include <WITCH/Memory.h>
#include <WITCH/Alloc.h>

#ifndef LD_WITCH_DBT_TreeNode
#define LD_WITCH_DBT_TreeNode
typedef T_uic LT_DBTTreeRoad;
#endif

/* #define LD_WITCH_DBT_AllowExplore */

#define LD_DBTRoadAmount 2
#define LD_DBTRoadSize sizeof(LT_DBTTreeRoad)
#define LD_DBTRoadsSize (LD_DBTRoadSize * LD_DBTRoadAmount)
#define LD_DBTNodeSize(M_Tree) (LD_DBTRoadsSize + (M_Tree)->OutputSize)
#define D_RoadStop(M_Map, M_CurrentStop, M_NewRoad) ((LT_DBTTreeRoad *)(M_Map->Nodes.ptr + (M_CurrentStop * LD_DBTNodeSize(M_Map))))[M_NewRoad]
#define LD_DBTRoadStopFood(M_Map, M_Stop) ((M_Map)->Nodes.ptr + (M_Stop * LD_DBTNodeSize((M_Map))) + LD_DBTRoadsSize)
#define D_PrepareBusForNextRoad(M_in, M_insize, M_seek, M_hdg){ \
	(M_in) += (M_seek == (M_hdg ? 0 : 7)) * (M_hdg ? -1 : 1); \
	(M_insize)--; \
	(M_seek) = (M_seek) == (M_hdg ? 0 : 7) ? (M_hdg ? 7 : 0) : (M_seek) + (M_hdg ? -1 : 1); \
}
#define D_PrepareBusForBackRoad(M_in, M_insize, M_seek, M_hdg){ \
	(M_in) -= (M_seek == (M_hdg ? 7 : 0)) * (M_hdg ? -1 : 1); \
	(M_insize)++; \
	(M_seek) = (M_seek) == (M_hdg ? 7 : 0) ? (M_hdg ? 0 : 7) : (M_seek) - (M_hdg ? -1 : 1); \
}
#define D_InitialIn(M_in, M_insize, M_hdg) \
	((M_in) + (M_insize > 8 ? ((M_hdg) ? (((M_insize - 8) / 8) + !!(M_insize & 7)) : 0) : 0))

typedef void(*LTF_DBTEmptyNode)(T_ptr);

typedef struct{
	LT_Alloc Nodes;
	T_ui OutputSize;
	LTF_DBTEmptyNode DBTEmptyNode;
	T_ui Empty, iEmpty;
	#ifdef LD_WITCH_DBT_AllowExplore
		LT_Alloc NodeHistory, RoadHistory;
	#endif
}LT_DBT;

LT_DBT LC_DBT(T_ui OutputSize, LTF_DBTEmptyNode DBTEmptyNode){
	LT_DBT Tree;
	Tree.OutputSize = OutputSize;
	Tree.Nodes = LDC_Alloc(LD_DBTNodeSize(&Tree));
	Tree.iEmpty = 0;
	Tree.DBTEmptyNode = DBTEmptyNode;
	LDF0_HandleAlloc(&Tree.Nodes, 1);
	LDF_MSet(0, LD_DBTRoadsSize * 8, Tree.Nodes.ptr);
	Tree.DBTEmptyNode(Tree.Nodes.ptr + LD_DBTRoadsSize);
	#ifdef LD_WITCH_DBT_AllowExplore
		Tree.NodeHistory = LDC_Alloc(sizeof(LT_DBTTreeRoad));
		Tree.RoadHistory = LDC_Alloc(1);
	#endif
	return Tree;
}

#define LDF_DBTGoOnRoads(M_Tree, M_iNode, M_iNodeV, M_in, M_inV, M_insize, M_insizeV, M_seek, M_seekV, ...) \
	LT_DBTTreeRoad M_iNode = M_iNodeV; \
	T_ptr M_in = M_inV; \
	T_ui M_insize = M_insizeV, M_seek = M_seekV; \
	while(LF_DBTGoOnRoads(M_Tree, &M_iNode, &M_in, &M_insize, &M_seek, (0, ##__VA_ARGS__)))
T_ui LF_DBTGoOnRoads(LT_DBT *Tree, LT_DBTTreeRoad *iNode, T_ptr *in, T_ui *insize, T_ui *seek, T_ui hdg){
	if(!*insize)
		return 0;
	LT_DBTTreeRoad tNode = D_RoadStop(Tree, *iNode, LDF_SeekAnd(**(T_ptr *)in, *seek));
	if(!tNode)
		return 0;
	*iNode = tNode;
	D_PrepareBusForNextRoad(*(T_ptr *)in, *insize, *seek, hdg);
	return 1;
}

#define LDF_DBTInTree(M_Tree, M_in, M_insize, M_out, ...) \
	LF_DBTInTree(M_Tree, (T_ptr)(M_in), (T_ui)(M_insize), (T_ptr)(M_out), (LD_LEFT_TO_RIGHT, ##__VA_ARGS__))
LT_DBTTreeRoad LF_DBTInTree(LT_DBT *Tree, T_ptr P_in, T_ui P_insize, T_ptr out, T_ui hdg){
	LDF_DBTGoOnRoads(Tree, iNode, 0, in, D_InitialIn(P_in, P_insize, hdg), insize, P_insize, seek, hdg ? 7 : 0, hdg);
	while(insize){
		iNode = D_RoadStop(Tree, iNode, LDF_SeekAnd(*(T_ptr)in, seek)) = Tree->iEmpty ? Tree->Empty : Tree->Nodes.Current;
		if(Tree->iEmpty){
			Tree->Empty = D_RoadStop(Tree, Tree->Empty, 0);
			Tree->iEmpty--;
		}
		else
			LDF0_HandleAlloc(&Tree->Nodes, 1);
		LDF_MSet(0, LD_DBTRoadsSize * 8, &D_RoadStop(Tree, iNode, 0));
		Tree->DBTEmptyNode(LD_DBTRoadStopFood(Tree, iNode));
		D_PrepareBusForNextRoad(in, insize, seek, hdg);
	}
	LDF_MCOP(out, Tree->OutputSize * 8, LD_DBTRoadStopFood(Tree, iNode));
	return iNode;
}

#define LDF_DBTOutTree(M_Tree, M_in, M_insize, ...) \
	LF_DBTOutTree((LT_DBT *)(M_Tree), (T_ptr)(M_in), (T_ui)(M_insize), (LD_LEFT_TO_RIGHT, ##__VA_ARGS__))
T_ptr LF_DBTOutTree(LT_DBT *Tree, T_ptr P_in, T_ui P_insize, T_ui hdg){
	LDF_DBTGoOnRoads(Tree, iNode, 0, in, D_InitialIn(P_in, P_insize, hdg), insize, P_insize, seek, hdg ? 7 : 0, hdg){}
	return insize ? 0 : LD_DBTRoadStopFood(Tree, iNode);
}

void LF_DeleteTreeNode_(LT_DBT *Tree, T_ui iNode){
	if(Tree->iEmpty)
		D_RoadStop(Tree, iNode, 0) = Tree->Empty;
	Tree->Empty = iNode;
	Tree->iEmpty++;
}

#define LDF_DeleteTreeNode(M_Tree, M_in, M_insize, ...) \
	LF_DeleteTreeNode((LT_DBT *)(M_Tree), (T_ptr)(M_in), (T_ui)(M_insize), (LD_LEFT_TO_RIGHT, ##__VA_ARGS__))
void LF_DeleteTreeNode(LT_DBT *Tree, T_ptr in, T_ui insize, T_ui hdg){
	in = D_InitialIn(in, insize, hdg);
	T_ui lowest = insize;
	LDF_DBTGoOnRoads(Tree, iNode, 0, _in, in, _insize, insize, seek, hdg ? 7 : 0, hdg)
		if((_insize && !LF_MCOM(LD_DBTRoadStopFood(Tree, 0), Tree->OutputSize, LD_DBTRoadStopFood(Tree, iNode))) || D_RoadStop(Tree, iNode, LDF_SeekAnd(*(T_ui *)_in, seek) ^ 1))
			lowest = _insize;
	if(_insize)
		return;
	Tree->DBTEmptyNode(LD_DBTRoadStopFood(Tree, iNode));
	if(D_RoadStop(Tree, iNode, 0) || D_RoadStop(Tree, iNode, 1))
		return;
	for(iNode = 0, seek = hdg ? 7 : 0; insize;){
		LT_DBTTreeRoad _iNode = D_RoadStop(Tree, iNode, LDF_SeekAnd(*(T_ui *)in, seek));
		if(insize <= lowest){
			if(insize < lowest)
				LF_DeleteTreeNode_(Tree, iNode);
			else
				D_RoadStop(Tree, iNode, LDF_SeekAnd(*(T_ui *)in, seek)) = 0;
		}
		iNode = _iNode;
		D_PrepareBusForNextRoad(in, insize, seek, hdg);
	}
	LF_DeleteTreeNode_(Tree, iNode);
}

#define LDF_DBTInTreeString(M_Tree, M_in, M_out) \
	LDF_DBTInTree(M_Tree, M_in, LDF_SSize(M_in) * 8, M_out)
#define LDF_DBTOutTreeString(M_Tree, M_in) \
	LDF_DBTOutTree(M_Tree, M_in, LDF_SSize(M_in) * 8)
#define LDF_DeleteTreeNodeString(M_Tree, M_in) \
	LDF_DeleteTreeNode(M_Tree, M_in, LDF_SSize(M_in) * 8)

#ifdef LD_WITCH_DBT_AllowExplore
	#define DC_WITCH_DBT_Explore_GetRoad(M_Tree, M_ibit) \
		LDF_GetBitInArray((M_Tree)->RoadHistory.ptr, M_ibit)
	#define DC_WITCH_DBT_Explore_SetRoad(M_Tree, M_ibit, M_bit) \
		LDF_SetBitInArray((M_Tree)->RoadHistory.ptr, M_ibit, M_bit)
	#define DC_WITCH_DBT_Explore_Set(M_Tree, M_progress, M_Node, M_Road) \
		((LT_DBTTreeRoad *)(M_Tree)->NodeHistory.ptr)[M_progress] = M_Node; \
		DC_WITCH_DBT_Explore_SetRoad(M_Tree, M_progress, M_Road)
	#define DC_WITCH_DBT_Explore_HandleAlloc(M_Tree, M_progress) \
		(M_Tree)->NodeHistory.Current = M_progress; \
		(M_Tree)->RoadHistory.Current = (M_progress / 8) + !!(M_progress % 8); \
		LDF_HandleAlloc(&(M_Tree)->NodeHistory); \
		LDF_HandleAlloc(&(M_Tree)->RoadHistory)

	#define LDF_WITCH_DBT_FindClosest(M_Tree, M_in, M_insize, M_b, ...) \
		LF_WITCH_DBT_FindClosest(M_Tree, M_in, M_insize, M_b, (0, ##__VA_ARGS__))
	LT_DBTTreeRoad LF_WITCH_DBT_FindClosest(LT_DBT *Tree, T_ptr P_in, T_ui P_insize, T_uia b, T_ui hdg){
		if(!P_insize)
			return ~0;
		DC_WITCH_DBT_Explore_HandleAlloc(Tree, P_insize);
		LDF_MCOP(P_in, P_insize, Tree->RoadHistory.ptr);
		LT_DBTTreeRoad iNode = 0;
		T_ptr in = D_InitialIn(Tree->RoadHistory.ptr, P_insize, LD_RIGHT_TO_LEFT);
		T_ui insize = P_insize, seek = 7;
		while(insize){
			LT_DBTTreeRoad tNode = D_RoadStop(Tree, iNode, LDF_SeekAnd(*(T_ptr)in, seek));
			while(!tNode){
				if(LDF_SeekAnd(*(T_ptr)in, seek) != b)
					tNode = D_RoadStop(Tree, iNode, b);
				if(!tNode){
					D_PrepareBusForBackRoad(in, insize, seek, hdg);
					if(insize > P_insize)
						return ~0;
					iNode = ((LT_DBTTreeRoad *)Tree->NodeHistory.ptr)[P_insize - insize];
				}
				else{
					LT_DBTTreeRoad _iNode = tNode;
					T_ptr _in = in;
					T_ui _insize = insize, _seek = seek;
					do{
						D_PrepareBusForNextRoad(_in, _insize, _seek, hdg);
						LT_DBTTreeRoad _tNode = 0;
						T_ui i = 1;
						for(; i < LD_DBTRoadAmount && !_tNode; i--)
							_tNode = D_RoadStop(Tree, _iNode, i);
						if(!_tNode)
							break;
						_iNode = _tNode;
					}while(_insize);
					if(!_insize)
						return _iNode;
				}
			}
			((LT_DBTTreeRoad *)Tree->NodeHistory.ptr)[P_insize - insize] = iNode;
			iNode = tNode;
			D_PrepareBusForNextRoad(in, insize, seek, hdg);
		}
		return iNode;
	}

	#define LFL_DBT_Explore(M_Tree) \
		DC_WITCH_DBT_Explore_HandleAlloc(M_Tree, 0) \
		DC_WITCH_DBT_Explore_Set(M_Tree, 0, 0, 0); \
		while(F_WITCH_DBT_Explore(M_Tree))
	T_ui F_WITCH_DBT_Explore(LT_DBT *Tree){
		LT_DBTTreeRoad *Nodes = (LT_DBTTreeRoad *)Tree->NodeHistory.ptr;
		T_si progress = Tree->NodeHistory.Current;
		LT_DBTTreeRoad node;
		GT_begin:
		while(!(node = D_RoadStop(Tree, Nodes[progress], DC_WITCH_DBT_Explore_GetRoad(Tree, progress)))){
			if(DC_WITCH_DBT_Explore_GetRoad(Tree, progress)){
				GT_back:
				progress--;
				if(progress < 0)
					return 0;
				if(!DC_WITCH_DBT_Explore_GetRoad(Tree, progress))
					DC_WITCH_DBT_Explore_SetRoad(Tree, progress, 1);
				else
					goto GT_back;
			}
			else
				DC_WITCH_DBT_Explore_SetRoad(Tree, progress, 1);
		}
		progress++;
		DC_WITCH_DBT_Explore_HandleAlloc(Tree, progress);
		DC_WITCH_DBT_Explore_Set(Tree, progress, node, 0);
		if(!LF_MCOM(LD_DBTRoadStopFood(Tree, 0), Tree->OutputSize, LD_DBTRoadStopFood(Tree, node)))
			return 1;
		else
			goto GT_begin;
	}
#endif

#undef D_PrepareBusForNextRoad
#undef D_PrepareBusForBackRoad
#undef D_RoadStop

#endif
