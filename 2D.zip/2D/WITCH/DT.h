#ifndef WITCH_DT
#define WITCH_DT
	#include <WITCH/Types.h>
	#include <WITCH/Alloc.h>
	#include <WITCH/Memory.h>

#ifndef WITCH_DT_CouplerSize
	typedef T_ui WITCH_DT_CouplerSize;
#endif

	struct LT_DT{
		T_ui BlockSize;
		struct LT_AllocSize Size;
		T_ui Empty, iEmpty;
		T_ptr Data;
	};

	#define LDC_DT(p) (struct LT_DT){p, LDC_AllocSize(p + sizeof(WITCH_DT_CouplerSize)), 0, 0, 0}

	#define WITCH_DT_GoBlock(px, py) (px->Data + ((py * (px->BlockSize + sizeof(WITCH_DT_CouplerSize)))))
	#define WITCH_DT_GoBlockD(px, py) (WITCH_DT_GoBlock(px, py) + sizeof(WITCH_DT_CouplerSize))

	WITCH_DT_CouplerSize LF_InDT(struct LT_DT *DT, T_ptr Data, T_ui iData){
		if(!DT->iEmpty){
			WITCH_DT_CouplerSize RET = DT->Size.Current;
			T_ui _iData;
GT_CreateBlock:
			_iData = iData;
			LF_HandleAlloc(&DT->Size, &DT->Data);
			LF_MemoryCopy(Data, (iData > DT->BlockSize ? DT->BlockSize : iData) * LD_ByteInBits, WITCH_DT_GoBlockD(DT, DT->Size.Current));
			Data += iData > DT->BlockSize ? DT->BlockSize : iData;
			if((iData -= DT->BlockSize) < _iData){
				DT->Size.Current++;
				LF_MemoryCopy(&DT->Size.Current, sizeof(WITCH_DT_CouplerSize) * LD_ByteInBits, WITCH_DT_GoBlock(DT, (DT->Size.Current - 1)));
				goto GT_CreateBlock;
			}
			DT->Size.Current++;
			WITCH_DT_CouplerSize Zero = 0;
			LF_MemoryCopy(&Zero, sizeof(WITCH_DT_CouplerSize) * LD_ByteInBits, WITCH_DT_GoBlock(DT, (DT->Size.Current - 1)));
			return RET;
		}
		else{
		}
	}

	WITCH_DT_CouplerSize LF_StringInDT(struct LT_DT *DT, T_ptr Data){
		return LF_InDT(DT, Data, LF_StringSize(Data));
	}

	T_ui LF_OutDT(struct LT_DT *DT, WITCH_DT_CouplerSize Block, T_ptr Data, T_ui Start, T_ui Size){
		T_ui Total = 0;
		WITCH_DT_CouplerSize _Block = Block;
		while(Total < Start - (Start % DT->BlockSize)){
			LF_MemoryCopy(WITCH_DT_GoBlock(DT, _Block), 4 * LD_ByteInBits, &_Block);
			if(_Block == 0)
				return 1;
			Total += DT->BlockSize;
		}
		Total = Start;
GT_Copy:
		LF_MemoryCopy(WITCH_DT_GoBlockD(DT, _Block) + (Total % DT->BlockSize), ((Size - Total) > (DT->BlockSize - (Total % DT->BlockSize)) ? (DT->BlockSize - (Total % DT->BlockSize)) : (Size - Total)) * LD_ByteInBits, Data + (Total - Start));
		Total += ((Size - Total) > (DT->BlockSize - (Total % DT->BlockSize)) ? (DT->BlockSize - (Total % DT->BlockSize)) : (Size - Total)); 
		if(Total == Size)
			return 0;
		LF_MemoryCopy(WITCH_DT_GoBlock(DT, _Block), 4 * LD_ByteInBits, &_Block);
		if(_Block == 0)
			return 1;
		goto GT_Copy;
	}
#endif
