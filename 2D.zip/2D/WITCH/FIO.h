#ifndef WITCH_FIO
#define WITCH_FIO

#include <stdio.h>
#include <WITCH/Types.h>
#include <WITCH/Alloc.h>
#include <WITCH/Memory.h>

typedef struct{
	T_ui Size;
	T_ptr Data;
}LT_File;

#define LDC_File LDC_WITCH(LT_File){0, 0}

#define LDF_FileReadAll(M_Path) LF_FileReadAll((T_ptr)M_Path)
LT_File LF_FileReadAll(T_ptr Path){
	FILE *in = fopen((const char *)Path, "rb");
	if(!in)
		return LDC_File;
	LT_File RET = LDC_File;
	fseek(in, 0, SEEK_END);
	RET.Size = ftell(in);
	fseek(in, 0, SEEK_SET);
	RET.Data = LDF_DebugResize(0, RET.Size);
	fread(RET.Data, RET.Size, 1, in);
	fclose(in);
	return RET;
}

//T_ui LF_FIODeleteFile(T_ptr path){
//	return (T_ui)remove(path);
//}

T_ui LF_FIOAddFileToFile(T_ptr src, T_ptr dst){
	LT_File Fsrc = LF_FileReadAll(src);
	if(!Fsrc.Data)
		return 1;
	FILE *Fdst = fopen((const char *)dst, "ab");
	if(!Fdst)
		return 2;
	fwrite(Fsrc.Data, Fsrc.Size, 1, Fdst);
	fclose(Fdst);
	LF_FreePTR(Fsrc.Data);
	return 0;
}

#define LDF_FIOWriteFile(M_src, M_srcsize, M_dst) LF_FIOWriteFile((T_ptr)M_src, (T_ui)M_srcsize, (T_ptr)M_dst)
T_ui LF_FIOWriteFile(T_ptr src, T_ui srcsize, T_ptr dst){
	FILE *Fdst = fopen((const char *)dst, "wb");
	fwrite(src, srcsize, 1, Fdst);
	fclose(Fdst);
	return 0;
}

#endif
