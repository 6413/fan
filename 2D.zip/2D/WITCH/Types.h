#ifndef WITCH_Types
#define WITCH_Types

#include <stdint.h>
#include <float.h>

#if UINTPTR_MAX == 0xffffffffffffffff
	#define D_ptrsize 64
#elif UINTPTR_MAX == 0xffffffff
	#define D_ptrsize 32
#elif UINTPTR_MAX == 0xffff
	#define D_ptrsize 16
#elif UINTPTR_MAX == 0xff
	#define D_ptrsize 8
#else
	#error Failed to find D_ptrsize
#endif

#define LD_LEFT_TO_RIGHT 0
#define LD_RIGHT_TO_LEFT 1

#define LDC_SeekOfint (D_ptrsize - 1)
#define DF_ArraySize(M_) (sizeof(M_) / sizeof((M_)[0]))

#define D_Swap(M_type, M_0, M_1) {M_type MV_temp = M_0; M_0 = M_1; M_1 = MV_temp;}

#ifdef __cplusplus
	#define LDC_WITCH(M_) M_
#else
	#define LDC_WITCH(M_) (M_)
#endif

/* integer */
typedef uint8_t T_uia;
typedef int8_t T_sia;
typedef uint16_t T_uib;
typedef int16_t T_sib;
typedef uint32_t T_uic;
typedef int32_t T_sic;
typedef uint64_t T_uid;
typedef int64_t T_sid;
typedef uintptr_t T_ui;
typedef intptr_t T_si;

typedef T_uia* T_ptr;

/* float */
typedef float T_fa;
typedef double T_fb;
#if D_ptrsize == 32
	typedef float T_f;
	#define D_FLT_MAX FLT_MAX
	#define D_PFMIN FLT_TRUE_MIN
#elif D_ptrsize == 64
	typedef double T_f;
	#define D_FLT_MAX DBL_MAX
	#define D_PFMIN DBL_TRUE_MIN
#endif

typedef struct{
	T_ptr ptr;
	T_ui size;
}T_ps;
#define DC_ps(M_ptr, M_size) (LDC_WITCH(T_ps){M_ptr, M_size})

typedef struct{
	T_ui x[2];
}T_2ui;
#define DC_2ui(M_0, M_1) (LDC_WITCH(T_2ui){(T_ui)(M_0), (T_ui)(M_1)})
typedef struct{
	T_si x[2];
}T_2si;
#define DC_2si(M_0, M_1) (LDC_WITCH(T_2si){(T_si)(M_0), (T_si)(M_1)})
typedef struct{
	T_f x[2];
}T_2f;
#define DC_2f(M_0, M_1) (LDC_WITCH(T_2f){(T_f)(M_0), (T_f)(M_1)})
typedef struct{
	T_f x[3];
}T_3f;
#define DC_3f(M_0, M_1, M_2) (LDC_WITCH(T_3f){(T_f)(M_0), (T_f)(M_1), (T_f)(M_2)})
typedef struct{
	T_f x[4];
}T_4f;
#define DC_4f(M_0, M_1, M_2, M_3) (LDC_WITCH(T_4f){(T_f)(M_0), (T_f)(M_1), (T_f)(M_2), (T_f)(M_3)})
typedef struct{
	T_2f x[2];
}T_2f2;
#define DC_2f2(M_0, M_1) (LDC_WITCH(T_2f2){{M_0, M_1}})
#define DC0_2f2(M_0, M_1, M_2, M_3) DC_2f2(DC_2f(M_0, M_1), DC_2f(M_2, M_3))
typedef struct{
	T_2ui x[2];
}T_2ui2;
#define DC_2ui2(M_0, M_1) (LDC_WITCH(T_2ui2){{M_0, M_1}})
#define DC0_2ui2(M_0, M_1, M_2, M_3) DC_2ui2(DC_2ui(M_0, M_1), DC_2ui(M_2, M_3))
typedef struct{
	T_2si x[2];
}T_2si2;
#define DC_2si2(M_0, M_1) (LDC_WITCH(T_2si2){{M_0, M_1}})
#define DC0_2si2(M_0, M_1, M_2, M_3) DC_2si2(DC_2si(M_0, M_1), DC_2si(M_2, M_3))
typedef struct{
	T_2f x[3];
}T_2f3;
#define DC_2f3(M_0, M_1, M_2) (LDC_WITCH(T_2f3){{M_0, M_1, M_2}})
#define DC0_2f3(M_0, M_1, M_2, M_3, M_4, M_5) DC_2f3(DC_2f(M_0, M_1), DC_2f(M_2, M_3), DC_2f(M_4, M_5))
typedef struct{
	T_2f x[4];
}T_2f4;
#define DC_2f4(M_0, M_1, M_2, M_3) (LDC_WITCH(T_2f4){{M_0, M_1, M_2, M_3}})
#define DC0_2f4(M_0, M_1, M_2, M_3, M_4, M_5, M_6, M_7) DC_2f4(DC_2f(M_0, M_1), DC_2f(M_2, M_3), DC_2f(M_4, M_5), DC_2f(M_6, M_7))

typedef struct{
	T_uic x[2];
}T_2uic;
#define DC_2uic(M_0, M_1) (LDC_WITCH(T_2uic){(T_uic)(M_0), (T_ui)(M_1)})

/* convertions */
#define DC_2uiT2f(M_0) DC_2f(M_0.x[0], M_0.x[1])
#define DC_2siT2f(M_0) DC_2f(M_0.x[0], M_0.x[1])
#define DC_2fT2ui(M_0) DC_2ui(M_0.x[0], M_0.x[1])
#define DC_2fT2si(M_0) DC_2si(M_0.x[0], M_0.x[1])
#define DC_2f2T2f4(M_0) DC0_2f4(M_0.x[0].x[0], M_0.x[0].x[1], M_0.x[1].x[0], M_0.x[0].x[1], M_0.x[1].x[0], M_0.x[1].x[1], M_0.x[0].x[0], M_0.x[1].x[1])

/* positive maker, works for T_f or T_si */
#define DF_WITCH_Types_USfORsi(M_) ((M_) < 0 ? -(M_) : (M_))

/*
OP means operator that changes first argument to output (except E)
OPR means operator that returns output
┌──────┬─────┬──────────┬────────┬──────────┬─────────┬────────────┐
│  P   │  S  │     M    │    D   │    U     │    E    │      A     │
├──────┼─────┼──────────┼────────┼──────────┼─────────┼────────────┤
│ Plus │ Sub │ Multiply │ Divide │ Unsigned │ isEqual │ Assignment │
└──────┴─────┴──────────┴────────┴──────────┴─────────┴────────────┘
*/

#define OP_2A2(M_0, M_1) {M_0.x[0] = M_1.x[0]; M_0.x[1] = M_1.x[1];}
#define OP_3A3(M_0, M_1) {M_0.x[0] = M_1.x[0]; M_0.x[1] = M_1.x[1]; M_0.x[2] = M_1.x[2];}
#define OP_4A4(M_0, M_1) {M_0.x[0] = M_1.x[0]; M_0.x[1] = M_1.x[1]; M_0.x[2] = M_1.x[2]; M_0.x[3] = M_1.x[3];}

#define OPR_U(M_) (Illegal_operator,) /* not possible without extension */
#define OPR_U1(M_) DF_WITCH_Types_USfORsi(M_)
#define OPR_U2(M_) (Illegal_operator,) /* not possible without extension */
#define OPR_U3(M_) (Illegal_operator,) /* not possible without extension */

#define OP_U(M_) (Illegal_operator,) /* not possible without extension */
#define OP_U1(M_) {M_ = OPR_U1(M_);}
#define OP_U2(M_) {OP_U1(M_.x[0]); OP_U1(M_.x[1]);}
#define OP_U3(M_) {OP_U1(M_.x[0]); OP_U1(M_.x[1]); OP_U1(M_.x[2]);}

#define OPR_U1f(M_) OPR_U1(M_)
#define OPR_U2f(M_) DC_2f(OPR_U1(M_.x[0]), OPR_U1(M_.x[1]))
#define OPR_U3f(M_) DC_3f(OPR_U1(M_.x[0]), OPR_U1(M_.x[1]), OPR_U1(M_.x[2]))
#define OP_U1f(M_) OP_U1(M_)
#define OP_U2f(M_) OP_U2(M_)
#define OP_U3f(M_) OP_U3(M_)

#define OPR_U1si(M_) OPR_U1(M_)
#define OPR_U2si(M_) DC_2si(OPR_U1(M_.x[0]), OPR_U1(M_.x[1]))
#define OPR_U3si(M_) DC_3si(OPR_U1(M_.x[0]), OPR_U1(M_.x[1]), OPR_U1(M_.x[2]))
#define OP_U1si(M_) OP_U1(M_)
#define OP_U2si(M_) OP_U2(M_)
#define OP_U3si(M_) OP_U3(M_)


#define OP_2P2(M_0, M_1) {M_0.x[0] += M_1.x[0]; M_0.x[1] += M_1.x[1];}
#define OP_2S2(M_0, M_1) {M_0.x[0] -= M_1.x[0]; M_0.x[1] -= M_1.x[1];}
#define OP_2M2(M_0, M_1) {M_0.x[0] *= M_1.x[0]; M_0.x[1] *= M_1.x[1];}
#define OP_2D2(M_0, M_1) {M_0.x[0] /= M_1.x[0]; M_0.x[1] /= M_1.x[1];}
#define OP_2E2(M_0, M_1) ((M_0.x[0] == M_1.x[0]) & (M_0.x[1] == M_1.x[1]))
#define OPR_2P2(M_0, M_1) (Illegal_operator,) /* not possible without extension */
#define OPR_2S2(M_0, M_1) (Illegal_operator,) /* not possible without extension */
#define OPR_2M2(M_0, M_1) (Illegal_operator,) /* not possible without extension */
#define OPR_2D2(M_0, M_1) (Illegal_operator,) /* not possible without extension */

/* 2f OP 2f */
#define OP_2fP2f(M_0, M_1) {M_0.x[0] += M_1.x[0]; M_0.x[1] += M_1.x[1];}
#define OP_2fS2f(M_0, M_1) {M_0.x[0] -= M_1.x[0]; M_0.x[1] -= M_1.x[1];}
#define OP_2fM2f(M_0, M_1) {M_0.x[0] *= (T_f)M_1.x[0]; M_0.x[1] *= (T_f)M_1.x[1];}
#define OP_2fD2f(M_0, M_1) {M_0.x[0] /= (T_f)M_1.x[0]; M_0.x[1] /= (T_f)M_1.x[1];}
#define OP_2fE2f(M_0, M_1) ((M_0.x[0] == M_1.x[0]) & (M_0.x[1] == M_1.x[1]))
#define OPR_2fP2f(M_0, M_1) DC_2f(M_0.x[0] + M_1.x[0], M_0.x[1] + M_1.x[1])
#define OPR_2fS2f(M_0, M_1) DC_2f(M_0.x[0] - M_1.x[0], M_0.x[1] - M_1.x[1])
#define OPR_2fM2f(M_0, M_1) DC_2f((T_f)M_0.x[0] * (T_f)M_1.x[0], (T_f)M_0.x[1] * (T_f)M_1.x[1])
#define OPR_2fD2f(M_0, M_1) DC_2f((T_f)M_0.x[0] / (T_f)M_1.x[0], (T_f)M_0.x[1] / (T_f)M_1.x[1])
/* 2f OP f */
#define OP_2fPf(M_0, M_1) {M_0.x[0] += M_1; M_0.x[1] += M_1;}
#define OP_2fSf(M_0, M_1) {M_0.x[0] -= M_1; M_0.x[1] -= M_1;}
#define OP_2fMf(M_0, M_1) {M_0.x[0] *= (T_f)(M_1); M_0.x[1] *= (T_f)(M_1);}
#define OP_2fDf(M_0, M_1) {M_0.x[0] /= (T_f)(M_1); M_0.x[1] /= (T_f)(M_1);}
#define OP_2fEf(M_0, M_1) ((M_0.x[0] == (M_1)) & (M_0.x[1] == (M_1)))
#define OPR_2fPf(M_0, M_1) DC_2f(M_0.x[0] + M_1, M_0.x[1] + M_1)
#define OPR_2fSf(M_0, M_1) DC_2f(M_0.x[0] - (M_1), M_0.x[1] - (M_1))
#define OPR_2fMf(M_0, M_1) DC_2f((T_f)M_0.x[0] * (T_f)(M_1), (T_f)M_0.x[1] * (T_f)(M_1))
#define OPR_2fDf(M_0, M_1) DC_2f((T_f)M_0.x[0] / (T_f)(M_1), (T_f)M_0.x[1] / (T_f)(M_1))
/* f OP 2f */
#define OP_fP2f(M_0, M_1) {M_0 += M_1.x[0]; M_0 += M_1.x[1];}
#define OP_fS2f(M_0, M_1) {M_0 -= M_1.x[0]; M_0 -= M_1.x[1];}
#define OP_fM2f(M_0, M_1) {M_0 *= (T_f)M_1.x[0]; M_0 *= (T_f)M_1.x[1];}
#define OP_fD2f(M_0, M_1) {M_0 /= (T_f)M_1.x[0]; M_0 /= (T_f)M_1.x[1];}
#define OP_fE2f(M_0, M_1) (((M_0) == M_1.x[0]) & ((M_0) == M_1.x[1]))
#define OPR_fP2f(M_0, M_1) (((M_0) + M_1.x[0]) + ((M_0) + M_1.x[1]))
#define OPR_fS2f(M_0, M_1) (((M_0) - M_1.x[0]) + ((M_0) - M_1.x[1]))
#define OPR_fM2f(M_0, M_1) (((T_f)(M_0) * (T_f)M_1.x[0]) + ((T_f)(M_0) * (T_f)M_1.x[1]))
#define OPR_fD2f(M_0, M_1) (((T_f)(M_0) / (T_f)M_1.x[0]) + ((T_f)(M_0) / (T_f)M_1.x[1]))

/* 2si OP 2si */
#define OP_2siP2si(M_0, M_1) {M_0.x[0] += M_1.x[0]; M_0.x[1] += M_1.x[1];}
#define OP_2siS2si(M_0, M_1) {M_0.x[0] -= M_1.x[0]; M_0.x[1] -= M_1.x[1];}
#define OP_2siM2si(M_0, M_1) {M_0.x[0] *= (T_f)M_1.x[0]; M_0.x[1] *= (T_f)M_1.x[1];}
#define OP_2siD2si(M_0, M_1) {M_0.x[0] /= (T_f)M_1.x[0]; M_0.x[1] /= (T_f)M_1.x[1];}
#define OP_2siE2si(M_0, M_1) ((M_0.x[0] == M_1.x[0]) & (M_0.x[1] == M_1.x[1]))
#define OPR_2siP2si(M_0, M_1) DC_2si(M_0.x[0] + (T_f)M_1.x[0], (T_f)M_0.x[1] + M_1.x[1])
#define OPR_2siS2si(M_0, M_1) DC_2si(M_0.x[0] - (T_f)M_1.x[0], (T_f)M_0.x[1] - M_1.x[1])
#define OPR_2siM2si(M_0, M_1) DC_2si((T_f)M_0.x[0] * (T_f)M_1.x[0], (T_f)M_0.x[1] * (T_f)M_1.x[1])
#define OPR_2siD2si(M_0, M_1) DC_2si((T_f)M_0.x[0] / (T_f)M_1.x[0], (T_f)M_0.x[1] / (T_f)M_1.x[1])
/* 2si OP si */
#define OP_2siPsi(M_0, M_1) {M_0.x[0] += M_1; M_0.x[1] += M_1;}
#define OP_2siSsi(M_0, M_1) {M_0.x[0] -= M_1; M_0.x[1] -= M_1;}
#define OP_2siMsi(M_0, M_1) {M_0.x[0] *= (M_1); M_0.x[1] *= (M_1);}
#define OP_2siDsi(M_0, M_1) {M_0.x[0] /= (M_1); M_0.x[1] /= (M_1);}
#define OP_2siEsi(M_0, M_1) ((M_0.x[0] == (M_1)) & (M_0.x[1] == (M_1)))
#define OPR_2siPsi(M_0, M_1) DC_2si(M_0.x[0] + M_1, M_0.x[1] + M_1)
#define OPR_2siSsi(M_0, M_1) DC_2si(M_0.x[0] - (M_1), M_0.x[1] - (M_1))
#define OPR_2siMsi(M_0, M_1) DC_2si(M_0.x[0] * (M_1), M_0.x[1] * (M_1))
#define OPR_2siDsi(M_0, M_1) DC_2si(M_0.x[0] / (M_1), M_0.x[1] / (M_1))
/* si OP 2si */
#define OP_siP2si(M_0, M_1) {M_0 += M_1.x[0]; M_0 += M_1.x[1];}
#define OP_siS2si(M_0, M_1) {M_0 -= M_1.x[0]; M_0 -= M_1.x[1];}
#define OP_siM2si(M_0, M_1) {M_0 *= M_1.x[0]; M_0 *= M_1.x[1];}
#define OP_siD2si(M_0, M_1) {M_0 /= M_1.x[0]; M_0 /= M_1.x[1];}
#define OP_siE2si(M_0, M_1) (((M_0) == M_1.x[0]) & ((M_0) == M_1.x[1]))
#define OPR_siP2si(M_0, M_1) (((M_0) + M_1.x[0]) + ((M_0) + M_1.x[1]))
#define OPR_siS2si(M_0, M_1) (((M_0) - M_1.x[0]) + ((M_0) - M_1.x[1]))
#define OPR_siM2si(M_0, M_1) (((M_0) * M_1.x[0]) + ((M_0) * M_1.x[1]))
#define OPR_siD2si(M_0, M_1) (((M_0) / M_1.x[0]) + ((M_0) / M_1.x[1]))

#define OP_2uiP2ui(M_0, M_1) {M_0.x[0] += M_1.x[0]; M_0.x[1] += M_1.x[1];}
#define OP_2uiS2ui(M_0, M_1) {M_0.x[0] -= M_1.x[0]; M_0.x[1] -= M_1.x[1];}
#define OP_2uiM2ui(M_0, M_1) {M_0.x[0] *= (T_f)M_1.x[0]; M_0.x[1] *= (T_f)M_1.x[1];}
#define OP_2uiD2ui(M_0, M_1) {M_0.x[0] /= (T_f)M_1.x[0]; M_0.x[1] /= (T_f)M_1.x[1];}
#define OP_2uiE2ui(M_0, M_1) ((M_0.x[0] == M_1.x[0]) & (M_0.x[1] == M_1.x[1]))
#define OPR_2uiP2ui(M_0, M_1) DC_2ui(M_0.x[0] + (T_f)M_1.x[0], (T_f)M_0.x[1] + M_1.x[1])
#define OPR_2uiS2ui(M_0, M_1) DC_2ui(M_0.x[0] - (T_f)M_1.x[0], (T_f)M_0.x[1] - M_1.x[1])
#define OPR_2uiM2ui(M_0, M_1) DC_2ui((T_f)M_0.x[0] * (T_f)M_1.x[0], (T_f)M_0.x[1] * (T_f)M_1.x[1])
#define OPR_2uiD2ui(M_0, M_1) DC_2ui((T_f)M_0.x[0] / (T_f)M_1.x[0], (T_f)M_0.x[1] / (T_f)M_1.x[1])

#endif
