#ifndef WITCH_Time
#define WITCH_Time

#include <time.h>
#include <WITCH/Types.h>

#ifdef _MSC_VER

#include <intrin.h>

T_uid LF_rdtsc(void){
	return __rdtsc();
}

#elif D_ptrsize == 32

T_uid LF_rdtsc(void){
	T_uid x;
	asm volatile (".byte 0x0f, 0x31" : "=A" (x));
	return x;
}

#elif D_ptrsize == 64

T_uid LF_rdtsc(void){
	T_uic hi, lo;
	asm volatile ("rdtsc" : "=a"(lo), "=d"(hi));
	return ((T_uid)lo) | (((T_uid)hi) << 32);
}

#endif

#ifdef _WIN32
	#include <windows.h>
#endif

typedef struct{
	T_ui yr;
	T_uia mo, d, w, hr, min, s;
}LT_date;

LT_date LFC_date(void){
	time_t t = time(NULL);
	struct tm tm = *localtime(&t);
	LT_date r = LDC_WITCH(LT_date){tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday, tm.tm_wday, tm.tm_hour, tm.tm_min, tm.tm_sec};
	return r;
}

T_f LF_timef(void){
	#ifdef _WIN32
		return (T_f)GetTickCount() / 1000;
	#else
		struct timespec t;
		clock_gettime(CLOCK_MONOTONIC, &t);
		return (T_f)t.tv_sec + (T_f)t.tv_nsec / 1000000000;
	#endif
}

T_uid LF_timei(void){
	#ifdef _WIN32
		return GetTickCount() * 1000000;
	#else
		struct timespec t;
		clock_gettime(CLOCK_MONOTONIC, &t);
		return (t.tv_sec * 1000000000) + t.tv_nsec;
	#endif
}

#endif
