#ifndef WITCH_Math
#define WITCH_Math

#include <WITCH/Types.h>

#define LDF_floor (T_f)(T_si)
#define LDF_fmod(M_Num, M_Mod) ((M_Num) - (LDF_floor((M_Num) / (M_Mod)) * (M_Mod)))
#define LDF_sign(M_) (T_si)(-(M_ < 0) | (M_ > 0))

T_f LF_atan2(T_2f x){
	T_f py = OPR_U1(x.x[1]), angle = x.x[0] >= 0 ? (45 - ((T_f)45 * (x.x[0] - py) / (x.x[0] + py))) : (135 - ((T_f)45 * (x.x[0] + py) / (py - x.x[0])));
	return x.x[1] < 0 ? 360 - angle : OP_2fE2f(x, DC_2f(0, 0)) ? 0 : angle;
}

T_f LF_sin(T_f progress){
	return progress < .25 ? (1 - progress * 4 * 2) : progress < .50 ? 1 : progress < .75 ? (-1 + (progress - .50) * 4 * 2) : -1;
}

T_f LF_cos(T_f progress){
	return progress < .25 ? -1 : progress < .50 ? (1 - (progress - .25) * 4 * 2) : progress < .75 ? 1 : (-1 + (progress - .75) * 4 * 2);
}

T_ui LF_HeavyBit(T_ui x){
	T_ui i = 1 << LDC_SeekOfint, p = D_ptrsize;
	while(i){
		if(x & i)
			break;
		i >>= 1;
		p--;
	}
	return p;
}

T_ui LF_log(T_ui num, T_ui base){
	T_ui log = 0;
	while(num){
		num /= base;
		log++;
	}
	return log;
}

T_f LF_MinFloat(void *ptr, T_ui i){
	T_f Min = D_FLT_MAX;
	T_ui i0 = 0;
	for(; i0 < i; i0++){
		if(((T_f *)ptr)[i0] < Min)
			Min = ((T_f *)ptr)[i0];
	}
	return Min;
}

T_f LF_PMinFloat(void *ptr, T_ui i){
	T_f Min = D_FLT_MAX;
	T_ui i0 = 0;
	for(; i0 < i; i0++){
		if(OPR_U1(((T_f *)ptr)[i0]) < Min)
			Min = OPR_U1(((T_f *)ptr)[i0]);
	}
	return Min;
}

T_f LF_MaxFloat(void *ptr, T_ui i){
	T_f Max = -D_FLT_MAX;
	T_ui i0 = 0;
	for(; i0 < i; i0++){
		if(((T_f *)ptr)[i0] > Max)
			Max = ((T_f *)ptr)[i0];
	}
	return Max;
}

T_f LF_PMaxFloat(void *ptr, T_ui i){
	T_f Max = -D_FLT_MAX;
	T_ui i0 = 0;
	for(; i0 < i; i0++){
		if(OPR_U1(((T_f *)ptr)[i0]) > Max)
			Max = OPR_U1(((T_f *)ptr)[i0]);
	}
	return Max;
}

void LF_PabsDiffFloat(void *ptr, T_ui i){
	T_f Min = LF_MinFloat(ptr, i);
	T_ui i0 = 0;
	for(; i0 < i; i0++)
		((T_f *)ptr)[i0] -= Min;
}

T_2f LF_Center2f(void *ptr, T_ui i){
	T_2f Center = DC_2f(0, 0);
	T_ui i0 = 0;
	for(; i0 < i; i0++){
		Center.x[0] += ((T_2f *)ptr)[i0].x[0];
		Center.x[1] += ((T_2f *)ptr)[i0].x[1];
	}
	Center.x[0] /= (T_f)i;
	Center.x[1] /= (T_f)i;
	return Center;
}

T_2f LF_Min2f(void *ptr, T_ui i){
	T_2f Min = DC_2f(D_FLT_MAX, D_FLT_MAX);
	T_ui i0 = 0;
	for(; i0 < i; i0++){
		if(((T_2f *)ptr)[i0].x[0] < Min.x[0])
			Min.x[0] = ((T_2f *)ptr)[i0].x[0];
		if(((T_2f *)ptr)[i0].x[1] < Min.x[1])
			Min.x[1] = ((T_2f *)ptr)[i0].x[1];
	}
	return Min;
}

T_2f LF_Max2f(void *ptr, T_ui i){
	T_2f Max = DC_2f(-D_FLT_MAX, -D_FLT_MAX);
	T_ui i0 = 0;
	for(; i0 < i; i0++){
		if(((T_2f *)ptr)[i0].x[0] > Max.x[0])
			Max.x[0] = ((T_2f *)ptr)[i0].x[0];
		if(((T_2f *)ptr)[i0].x[1] > Max.x[1])
			Max.x[1] = ((T_2f *)ptr)[i0].x[1];
	}
	return Max;
}

void LF_PabsDiff2f(void *ptr, T_ui i){
	T_2f Min = LF_Min2f(ptr, i);
	T_ui i0 = 0;
	for(; i0 < i; i0++){
		((T_2f *)ptr)[i0].x[0] -= Min.x[0];
		((T_2f *)ptr)[i0].x[1] -= Min.x[1];
	}
}

void LF_CabsDiff2f(void *ptr, T_ui i){
	T_2f Min = LF_Min2f(ptr, i);
	T_ui i0;
	for(i0 = 0; i0 < i; i0++){
		((T_2f *)ptr)[i0].x[0] -= Min.x[0];
		((T_2f *)ptr)[i0].x[1] -= Min.x[1];
	}
	T_2f Center = LF_Center2f(ptr, i);
	for(i0 = 0; i0 < i; i0++){
		((T_2f *)ptr)[i0].x[0] -= Center.x[0];
		((T_2f *)ptr)[i0].x[1] -= Center.x[1];
	}
}

#define LDF_HDG2(M_src, M_dst) OPR_2fDf(OPR_2fS2f(M_src, M_dst), (OPR_U1(OPR_2fS2f(M_src, M_dst).x[0]) > OPR_U1(OPR_2fS2f(M_src, M_dst).x[1]) ? OPR_U1(OPR_2fS2f(M_src, M_dst).x[0]) : OPR_U1(OPR_2fS2f(M_src, M_dst).x[1])))
#define LDF_Normalize(M_src) OPR_2fDf(M_src, OP_2fE2f(M_src, DC_2f(0, 0)) ? 1 : OPR_fP2f(0, OPR_U2f(M_src)))
#define LDF_absAngle(M_src, M_dst, M_Multipler) OPR_2fMf(LDF_Normalize(OPR_2fS2f(M_src, M_dst)), M_Multipler)

#define LDF_DBf(M_x, M_y) OPR_U1(M_x - M_y)
#define LDF_DB2f(M_x, M_y) (OPR_U1(M_x.x[0] - M_y.x[0]) + OPR_U1(M_x.x[1] - M_y.x[1]))

T_ui LF_MinSiIndex(T_si *x, T_ui am){
	T_ui Min = 0;
	while(am){
		if(x[am - 1] < x[Min])
			Min = am - 1;
		am--;
	}
	return Min;
}

T_2si LF_ClosestDirection2(T_2si src, T_2si dst, T_ui Order){
	T_2si dir[4] = {DC_2si(1, 0), DC_2si(0, 1), DC_2si(-1, 0), DC_2si(0, -1)};
	T_si dis[4];
	T_ui i;
	for(i = 0; i < 4; i++)
		dis[i] = LDF_DB2f(OPR_2siP2si(src, dir[i]), dst);
	for(i = 4; i > 1; i--){
		T_ui index = LF_MinSiIndex(&dis[4 - i], i);
		T_si s = dis[4 - i];
		dis[4 - i] = dis[index + (4 - i)];
		dis[index + (4 - i)] = s;
		T_2si s2 = dir[4 - i];
		dir[4 - i] = dir[index + (4 - i)];
		dir[index + (4 - i)] = s2;
	}
	return dir[Order];
}

T_ui LF_IsPoColPo(T_2f p0, T_2f p1, T_f Size){
	if(LDF_DBf(p0.x[0], p1.x[0]) < Size && LDF_DBf(p0.x[1], p1.x[1]) < Size)
		return 1;
	return 0;
}

T_ui LFi_IsPoInsSqu(T_2si p0, T_2si2 p1){
	if(p0.x[0] >= p1.x[1].x[0])
		return 0;
	if(p0.x[0] <= p1.x[0].x[0])
		return 0;
	if(p0.x[1] >= p1.x[1].x[1])
		return 0;
	if(p0.x[1] <= p1.x[0].x[1])
		return 0;
	return 1;
}

T_ui LF_IsPoInsPoly(T_2f *Polygon, T_ui iPolygon, T_2f Point){
	T_ui i = 0, j = iPolygon - 1, c = 0;
	for(; i < iPolygon; j = i++){
		if(((Polygon[i].x[1] > Point.x[1]) != (Polygon[j].x[1] > Point.x[1])) && (Point.x[0] < (Polygon[j].x[0] - Polygon[i].x[0]) * (Point.x[1] - Polygon[i].x[1]) / (Polygon[j].x[1] - Polygon[i].x[1]) + Polygon[i].x[0]))
			c = !c;
	}
	return c;
}

T_ui LF_LineColLine(T_2f2 p0, T_2f2 p1){
	T_f d = ((p0.x[1].x[0] - p0.x[0].x[0]) * (p1.x[1].x[1] - p1.x[0].x[1])) - ((p0.x[1].x[1] - p0.x[0].x[1]) * (p1.x[1].x[0] - p1.x[0].x[0]));
	T_f n1 = ((p0.x[0].x[1] - p1.x[0].x[1]) * (p1.x[1].x[0] - p1.x[0].x[0])) - ((p0.x[0].x[0] - p1.x[0].x[0]) * (p1.x[1].x[1] - p1.x[0].x[1]));
	T_f n2 = ((p0.x[0].x[1] - p1.x[0].x[1]) * (p0.x[1].x[0] - p0.x[0].x[0])) - ((p0.x[0].x[0] - p1.x[0].x[0]) * (p0.x[1].x[1] - p0.x[0].x[1]));

	if(d == 0)
		return n1 == 0 && n2 == 0;

	T_f r = n1 / d;
	T_f s = n2 / d;

	return (r >= 0 && r <= 1) && (s >= 0 && s <= 1);
}

T_ui LF_LineColQuad(T_2f2 Line, T_2f4 Quad){
	#define LineColLine(dp0, dp1) if(LF_LineColLine(Line, DC_2f2(Quad.x[dp0], Quad.x[dp1]))) return 1;
		LineColLine(0, 1);
		LineColLine(1, 2);
		LineColLine(2, 3);
		LineColLine(3, 0);
	#undef LineColLine
	return LF_IsPoInsPoly((T_2f *)&Quad, 4, Line.x[0]) > 0 ? 1 : 0; 
}

#define LDF_PoToSqu(M_Po, M_Size) (DC0_2f2(M_Po.x[0] - ((T_f)M_Size / 2), M_Po.x[1] - ((T_f)M_Size / 2), M_Po.x[0] + ((T_f)M_Size / 2), M_Po.x[1] + ((T_f)M_Size / 2)))

typedef struct{
	T_2f HDG, src, dst;
	T_2si grid;
}LT_gridRaycast;
T_ui F_WITCH_Math_gridRaycast(LT_gridRaycast *RET, T_f GridSize){
	T_2f pos = DC_2f(LDF_fmod(RET->src.x[0], GridSize), LDF_fmod(RET->src.x[1], GridSize));
	T_2f closest = OPR_U2f(OPR_2fPf(OPR_U2f(OPR_2fSf(pos, GridSize / 2)), -GridSize / 2));
	pos.x[0] = ((RET->HDG.x[0] < 0) ? pos.x[0] : GridSize - pos.x[0]); if(closest.x[0] == 0) pos.x[0] = GridSize;
	pos.x[1] = ((RET->HDG.x[1] < 0) ? pos.x[1] : GridSize - pos.x[1]); if(closest.x[1] == 0) pos.x[1] = GridSize;
	pos = OPR_U2f(OPR_2fD2f(pos, RET->HDG));
	RET->src = OPR_2fP2f(RET->src, OPR_2fMf(RET->HDG, LF_MinFloat(&pos, 2)));
	RET->grid = DC_2fT2si(OPR_2fDf(RET->src, GridSize));
	RET->grid.x[0] -= (RET->HDG.x[0] < 0) && (pos.x[0] <= pos.x[1]);
	RET->grid.x[1] -= (RET->HDG.x[1] < 0) && (pos.x[1] <= pos.x[0]);
	T_2f newHDG = LDF_HDG2(RET->dst, RET->src);
	return !((LDF_sign(newHDG.x[0]) != LDF_sign(RET->HDG.x[0])) || (LDF_sign(newHDG.x[1]) != LDF_sign(RET->HDG.x[1])));
}
#define LDF_gridRaycast(M_oldPos, M_newPos, M_varName, M_gridSize) \
	LT_gridRaycast M_varName = LDC_WITCH(LT_gridRaycast){LDF_HDG2(M_newPos, M_oldPos), M_oldPos, M_newPos, DC_2si(0, 0)}; \
	if(!OP_2fE2f(M_varName.src, M_varName.dst)) \
	while(F_WITCH_Math_gridRaycast(&M_varName, M_gridSize))

#endif
