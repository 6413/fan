/* Holy Sort */

#ifndef WITCH_HS
#define WITCH_HS

#define LD_WITCH_DBT_AllowExplore

#include <WITCH/Types.h>
#include <WITCH/VAS.h>
#include <WITCH/DBT.h>

void F_WITCH_HS_DBTEmptyNode(T_ptr ptr){
	LF_MSet(0, sizeof(T_uic) * 8, ptr);
}

typedef struct{
	LT_VAS vas;
	LT_DBT dbt; /* TODO WE NEED CBT NOT DBT!!!!!!! */
	T_ui np, ns;
}LT_HS;
#define LDC_HS(M_size, M_np, M_ns) \
	LDC_WITCH(LT_HS){LC_VAS(M_size), LC_DBT(sizeof(LT_VAS_Node), F_WITCH_HS_DBTEmptyNode), M_np, M_ns}
#define LC_HS(...) \
	LDC_HS(__VA_ARGS__)

void LF_HS_In(LT_HS *HS, T_ptr stack){
	T_ui nr = *(T_ui *)(stack + HS->np);
	if(LD_VAS_TotalNodes(&HS->vas)){
		LT_DBTTreeRoad dbtq = LDF_WITCH_DBT_FindClosest(&HS->dbt, (T_ptr)&nr, HS->ns, 0, LD_RIGHT_TO_LEFT);
		if(dbtq != ~0){
			LT_VAS_Node vnode = *(LT_VAS_Node *)LD_DBTRoadStopFood(&HS->dbt, dbtq);
			T_ui _vnode = *(T_ui *)(LD_VAS_NodeOUT(&HS->vas, vnode) + HS->np);
			if(nr != _vnode){ /* TODO NOT LINEAR!!!!!!! */
				while(vnode != LD_VAS_LastNode(&HS->vas)){
					LT_VAS_Node nextnode = LD_VAS_NodePTR(&HS->vas, vnode);
					if(_vnode != *(T_ui *)(LD_VAS_NodeOUT(&HS->vas, nextnode) + HS->np))
						break;
					vnode = nextnode;
				}
				LT_VAS_Node onode = LDF_VAS_AddNodeNext(&HS->vas, vnode);
				LDF_DBTInTree(&HS->dbt, &nr, HS->ns, &onode, LD_RIGHT_TO_LEFT);
				LDF_MCOP(stack, HS->vas.OutputSize * 8, LD_VAS_NodeOUT(&HS->vas, onode));
			}
			else{
				LT_VAS_Node onode = LDF_VAS_AddNodeNext(&HS->vas, vnode);
				LDF_MCOP(stack, HS->vas.OutputSize * 8, LD_VAS_NodeOUT(&HS->vas, onode));
			}
		}
		else{
			LT_VAS_Node zero = 0;
			LDF_VAS_AddNodeBack(&HS->vas, 0){
				T_ui _nr = *(T_ui *)(LD_VAS_NodeOUT(&HS->vas, 0) + HS->np);
				LDF_DBTInTree(&HS->dbt, &_nr, HS->ns, &MV_Node, LD_RIGHT_TO_LEFT);
			}
			LDF_DBTInTree(&HS->dbt, &nr, HS->ns, &zero, LD_RIGHT_TO_LEFT);
			LDF_MCOP(stack, HS->vas.OutputSize * 8, LD_VAS_NodeOUT(&HS->vas, zero));
		}
	}
	else{
		LT_VAS_Node node = LDF_InVAS_(&HS->vas, 0);
		LDF_DBTInTree(&HS->dbt, &nr, HS->ns, &node, LD_RIGHT_TO_LEFT);
		LDF_MCOP(stack, HS->vas.OutputSize * 8, LD_VAS_NodeOUT(&HS->vas, node));
	}
}

void LF_HS_rm(LT_HS *HS, LT_VAS_Node node){
	LT_VAS_Node *dbtnode = (LT_VAS_Node *)LDF_DBTOutTree(&HS->dbt, LD_VAS_NodeOUT(&HS->vas, node) + HS->np, HS->ns, LD_RIGHT_TO_LEFT);
	if(*dbtnode == node){
		if(node != LD_VAS_LastNode(&HS->vas)){
			if(*(T_ui *)(LD_VAS_NodeOUT(&HS->vas, LD_VAS_NodePTR(&HS->vas, node)) + HS->np) == *(T_ui *)(LD_VAS_NodeOUT(&HS->vas, node) + HS->np))
				*dbtnode = LD_VAS_NodePTR(&HS->vas, node);
			else
				LDF_DeleteTreeNode(&HS->dbt, LD_VAS_NodeOUT(&HS->vas, node) + HS->np, HS->ns, LD_RIGHT_TO_LEFT);
			LDF_VAS_rm_node(&HS->vas, node)
				*(LT_VAS_Node *)LDF_DBTOutTree(&HS->dbt, LD_VAS_NodeOUT(&HS->vas, MV_Node) + HS->np, HS->ns, LD_RIGHT_TO_LEFT) = node;
		}
		else{
			LDF_DeleteTreeNode(&HS->dbt, LD_VAS_NodeOUT(&HS->vas, node) + HS->np, HS->ns, LD_RIGHT_TO_LEFT);
			LDF_VAS_rm_node(&HS->vas, node);
		}
	}
	else{
		LDF_VAS_rm_node(&HS->vas, node){
			LT_VAS_Node *nnode = (LT_VAS_Node *)LDF_DBTOutTree(&HS->dbt, LD_VAS_NodeOUT(&HS->vas, MV_Node) + HS->np, HS->ns, LD_RIGHT_TO_LEFT);
			if(*nnode == MV_Node)
				*nnode = node;
		}
	}
}

#endif
