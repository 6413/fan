#ifndef WITCH_Random
#define WITCH_Random

#define WITCH_Random_MAX 0xffff

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include <WITCH/Types.h>

typedef struct{
	time_t TIME;
}LT_Random;

LT_Random LFC_Random(void){
	LT_Random RET;
	srand(time(&RET.TIME));
	return RET;
}

T_si LF_Random(T_si Min, T_si Max){
	return rand() % ((Max - Min) + 1) + Min;
}

#endif
