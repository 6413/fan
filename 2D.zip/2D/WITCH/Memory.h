#ifndef WITCH_Memory
#define WITCH_Memory

#include <stdarg.h>
#include <WITCH/Types.h>
#include <WITCH/Alloc.h>
#include <WITCH/Math.h>

#define LDC_HighSeek ((T_ui)1 << LDC_SeekOfint)
#define LDF_SeekAnd(px, py) (((px) >> (py)) & 1)

#define LD_ByteInBits 8
#define LD_ptrsizeD (D_ptrsize / LD_ByteInBits)
#define LDF_BitsToByte(x) (x / LD_ByteInBits)

#define LDF_GetBitInArray(M_array, M_ibit) \
	LDF_SeekAnd(*(T_uia *)((T_ptr)M_array + (M_ibit / LD_ByteInBits)), M_ibit % LD_ByteInBits)
#define LDF_SetBitInArray(M_array, M_ibit, M_bit) \
	*(T_uia *)((T_ptr)M_array + (M_ibit / LD_ByteInBits)) ^= (-M_bit ^ *(T_uia *)((T_ptr)M_array + (M_ibit / LD_ByteInBits))) & (1 << (M_ibit % LD_ByteInBits))

#define LDF_ReverseArray(M_Array, M_Size, M_Element){ \
	T_ui MV_LDF_ReverseArray_i = 0; \
	for(; MV_LDF_ReverseArray_i < (M_Size / 2); MV_LDF_ReverseArray_i++){ \
		M_Element MV_LDF_ReverseArray_temp = ((M_Element *)M_Array)[MV_LDF_ReverseArray_i]; \
		((M_Element *)M_Array)[MV_LDF_ReverseArray_i] = ((M_Element *)M_Array)[(M_Size - 1) - MV_LDF_ReverseArray_i]; \
		((M_Element *)M_Array)[(M_Size - 1) - MV_LDF_ReverseArray_i] = MV_LDF_ReverseArray_temp; \
	} \
}

T_ui LDF_SwapEndian_(T_ui x){LDF_ReverseArray(&x, sizeof(T_ui), T_uia); return x;}
T_uid LDF_SwapEndian_8(T_uid x){LDF_ReverseArray(&x, sizeof(T_uid), T_uia); return x;}
T_uic LDF_SwapEndian_4(T_uic x){LDF_ReverseArray(&x, sizeof(T_uic), T_uia); return x;}
T_uib LDF_SwapEndian_2(T_uib x){LDF_ReverseArray(&x, sizeof(T_uib), T_uia); return x;}

#define LDF_MCOP(M_src, M_isrc, M_dst) LF_MCOP((T_ptr)M_src, M_isrc, (T_ptr)M_dst)
void LF_MCOP(T_ptr src, T_ui isrc, T_ptr dst){
	T_ui AfterPad = isrc % D_ptrsize;
	isrc = (isrc - AfterPad) / LD_ByteInBits;
	while(isrc){
		*(T_ui *)dst = *(T_ui *)src;
		dst += LD_ptrsizeD;
		src += LD_ptrsizeD;
		isrc -= LD_ptrsizeD;
	}
	*(T_ui *)dst = ((*(T_ui *)dst >> AfterPad) << AfterPad) | (*(T_ui *)src & (((T_ui)1 << AfterPad) - 1));
}

#define LDF_MSet(M_src, M_isrc, M_dst) LF_MSet(M_src, M_isrc, (T_ptr)M_dst)
void LF_MSet(T_ui src, T_ui isrc, T_ptr dst){
	T_ui AfterPad = isrc % D_ptrsize;
	isrc = (isrc - AfterPad) / LD_ByteInBits;
	while(isrc){
		*(T_ui *)dst = src;
		dst += LD_ptrsizeD;
		isrc -= LD_ptrsizeD;
	}
	*(T_ui *)dst = ((*(T_ui *)dst >> AfterPad) << AfterPad) | src & (((T_ui)1 << AfterPad) - 1);
}

#define LDF_MCOM(M_src, M_isrc, M_dst) LF_MCOM((T_ptr)M_src, M_isrc, (T_ptr)M_dst)
T_ui LF_MCOM(T_ptr src, T_ui isrc, T_ptr dst){
	T_ui AfterPad = isrc % D_ptrsize;
	isrc = (isrc - AfterPad) / LD_ByteInBits;
	while(isrc){
		if(*(T_ui *)dst != *(T_ui *)src)
			return 0;
		dst += LD_ptrsizeD;
		src += LD_ptrsizeD;
		isrc -= LD_ptrsizeD;
	}
	if(((*(T_ui *)dst & (((T_ui)1 << AfterPad) - 1)) != (*(T_ui *)src & (((T_ui)1 << AfterPad) - 1))))
		return 0;
	return 1;
}

#define LDF_SSize(M_str) LF_SSize((T_sia *)M_str)
T_ui LF_SSize(T_sia *x){
	T_ui y = 0;
	while(x[y])
		y++;
	return y;
}

#define LDF_SFindChar(M_str, M_c) LF_SFindChar((T_sia *)M_str, (T_sia)M_c)
T_ui LF_SFindChar(T_sia *x, T_sia c){
	T_ui y = 0;
	while(x[y] && x[y] != c)
		y++;
	return y;
}

T_ui LF_WordSize(T_sia *str, T_ui i, T_ui size){
	T_ui begin = i;
	while(i < size){
		if((str[i] >= 'A' && str[i] <= 'Z') || (str[i] >= 'a' && str[i] <= 'z') || str[i] == '_')
			i++;
		else break;
	}
	return i - begin;
}

T_ui LF_OperatorSize(T_sia *str, T_ui i, T_ui size){
	T_ui begin = i;
	while(i < size){
		if(str[i] == '+' || str[i] == '-' || str[i] == '*' || str[i] == '/' || str[i] == '!' || str[i] == '=' || str[i] == '<' || str[i] == '>')
			i++;
		else break;
	}
	return i - begin;
}

#define LDF_SCOM(M_0, M_1) LF_SCOM((T_uia *)M_0, (T_uia *)M_1)
T_ui LF_SCOM(T_uia *x, T_uia *y){
	T_ui offset = 0;
	while(x[offset] == y[offset] && x[offset] != 0 && y[offset] != 0)
		offset++;
	return x[offset] == 0 ? 1 : 0;
}

#define LDF_DecToint(M_str) LF_DecToint((T_sia *)M_str)
T_ui LF_DecToint(T_sia *str){
	T_ui res = 0, i = 0;
	for(; str[i] >= '0' && str[i] <= '9'; ++i)
		res = res * 10 + str[i] - '0';
	return res;
}

#define LDF0_DecToint(M_str, M_Size) LF0_DecToint((T_sia *)M_str, (T_ui)M_Size)
T_ui LF0_DecToint(T_sia *str, T_ui Size){
	T_ui res = 0, i = 0;
	for(; str[i] >= '0' && str[i] <= '9' && i < Size; ++i)
		res = res * 10 + str[i] - '0';
	return res;
}

#define LDF_DecdToint(M_str) LF_DecdToint((T_sia *)M_str)
T_f LF_DecdToint(T_sia *str){
	T_f res = 0;
	T_ui i = 0, Dot = 0;
	for(; str[i] != '\0'; ++i){
		Dot *= 10;
		if(str[i] == '.')
			Dot = Dot ? Dot : 1;
		else if(str[i] >= '0' && str[i] <= '9')
			res = Dot ? res + ((T_f)(str[i] - '0') / Dot): res * 10 + str[i] - '0';
		else break;
	}
	return res;
}

#define LDF0_DecdToint(M_str, M_Size) LF0_DecdToint((T_sia *)M_str, (T_ui)M_Size)
T_f LF0_DecdToint(T_sia *str, T_ui Size){
	T_f res = 0;
	T_ui i = 0, Dot = 0;
	for(; str[i] != '\0' && i < Size; ++i){
		Dot *= 10;
		if(str[i] == '.')
			Dot = Dot ? Dot : 1;
		else if(str[i] >= '0' && str[i] <= '9')
			res = Dot ? res + ((T_f)(str[i] - '0') / Dot) : res * 10 + str[i] - '0';
		else break;
	}
	return res;
}

typedef struct{
	T_sia *ptr;
	T_ui size;
}LT_string;

LT_string LF_string_GoLine(T_sia *ptr, T_ui n){
	LT_string line;
	for(line.ptr = ptr;;){
		line.size = LF_SFindChar(line.ptr, '\n');
		if(!n--)
			break;
		line.ptr += line.size + 1;
	}
	return line;
}

void F_WITCH_MEMORY_FSsi(LT_Alloc *Alloc, T_si in, T_si base){
	if(in < 0){
		LDF_iAllocAdd(Alloc, T_sia, '-');
		OP_U1(in);
	}
	Alloc->Current += LF_log(in, base) + !in;
	LDF_HandleAlloc(Alloc);
	T_sia *ptr = &((T_sia *)Alloc->ptr)[Alloc->Current];
	*(--ptr) = '0';
	while(in){
		T_ui vm = (in % base);
		*ptr-- = (vm > 9 ? 'W' : '0') + vm;
		in /= base;
	}
}

void F_WITCH_MEMORY_FSs(LT_Alloc *Alloc, T_sia *str){
	while(*str){
		LDF_iAllocAdd(Alloc, T_sia, *str);
		str++;
	}
}

void LF_FS(LT_Alloc *Alloc, T_sia *str, ...){
	Alloc->Current = 0;
	T_ui i, argc = 0;
	for(i = 0; str[i]; i++){
		LDF_HandleAlloc(Alloc);
		if(str[i] == '%'){
			if(str[i + 1] == 'i' || str[i + 1] == 's'){
				i += 2;
				argc++;
				continue;
			}
		}
	}

	va_list argv;
	va_start(argv, argc);
	for(i = 0; str[i]; i++){
		if(str[i] == '%'){
			if(str[i + 1] == 'i'){
				i++;
				F_WITCH_MEMORY_FSsi(Alloc, va_arg(argv, T_si), 10);
				continue;
			}
			if(str[i + 1] == 's'){
				i++;
				F_WITCH_MEMORY_FSs(Alloc, va_arg(argv, T_sia *));
				continue;
			}
		}
		LDF_iAllocAdd(Alloc, T_sia, str[i]);
	}
	va_end(argv);
}

#endif
