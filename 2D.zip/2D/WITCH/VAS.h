#ifndef WITCH_VAS
#define WITCH_VAS

#include <WITCH/Types.h>
#include <WITCH/Memory.h>
#include <WITCH/Alloc.h>

#define LD_VAS_NodeSize(M_) (sizeof(LT_VAS_Node) + (M_)->OutputSize)
#define LD_VAS_TotalNodes(M_) ((M_)->Nodes.Current - (M_)->EmptyNodes.Possible)
#define LD_VAS_NodePTR(M_VAS, M_i) *(LT_VAS_Node *)((M_VAS)->Nodes.ptr + (M_i * LD_VAS_NodeSize(M_VAS)))
#define LD_VAS_NodeOUT(M_VAS, M_i) ((M_VAS)->Nodes.ptr + ((M_i) * LD_VAS_NodeSize(M_VAS)) + sizeof(LT_VAS_Node))

#define LD_WITCH_VAS_LastNode(M_VAS) \
	(LD_VAS_TotalNodes(M_VAS) ? F_WITCH_VAS_FindNode(M_VAS, LD_VAS_TotalNodes(M_VAS) - 1) : 0)

#ifndef LD_WITCH_VAS_FPS_LASTNODE
	#define LD_WITCH_VAS_FPS_LASTNODE 1
#endif
#ifndef LD_WITCH_VAS_FPS_LASTUSED
	#define LD_WITCH_VAS_FPS_LASTUSED 1
#endif

#if LD_WITCH_VAS_FPS_LASTNODE == 0
	#define LD_VAS_LastNode(M_VAS) \
		LD_WITCH_VAS_LastNode(M_VAS)
#elif LD_WITCH_VAS_FPS_LASTNODE == 1
	#define LD_VAS_LastNode(M_VAS) \
		(M_VAS)->LastNode
#endif

#ifndef LD_WITCH_VAS_Node
#define LD_WITCH_VAS_Node
typedef T_uic LT_VAS_Node;
#endif

typedef struct{
	T_ui Current, Possible;
}T_WITCH_VAS_EmptyNodes;
#define DF_WITCH_VAS_EmptyNodes(M_Current, M_Possible) \
	(LDC_WITCH(T_WITCH_VAS_EmptyNodes){M_Current, M_Possible})

typedef struct{
	LT_Alloc Nodes;
	T_WITCH_VAS_EmptyNodes EmptyNodes;
	T_ui OutputSize;

	#if LD_WITCH_VAS_FPS_LASTNODE == 1
		LT_VAS_Node LastNode;
	#endif
	#if LD_WITCH_VAS_FPS_LASTUSED == 1
		LT_VAS_Node LastUsedi, LastUsedn;
	#endif
}LT_VAS;
LT_VAS LC_VAS(T_ui OutputSize){
	LT_VAS ret;
	ret.Nodes = LDC_Alloc(sizeof(LT_VAS_Node) + OutputSize);
	ret.EmptyNodes = DF_WITCH_VAS_EmptyNodes(0, 0);
	ret.OutputSize = OutputSize;
	#if LD_WITCH_VAS_FPS_LASTNODE == 1
		ret.LastNode = 0;
	#endif
	#if LD_WITCH_VAS_FPS_LASTUSED == 1
		ret.LastUsedi = 0;
		ret.LastUsedn = 0;
	#endif
	return ret;
}

LT_VAS_Node F_WITCH_VAS_FindNode(LT_VAS *VAS, LT_VAS_Node in){
	LT_VAS_Node CurrentNode = 0, i = 0;
	#if LD_WITCH_VAS_FPS_LASTUSED == 1
		if(in >= VAS->LastUsedi){
			CurrentNode = VAS->LastUsedn;
			i = VAS->LastUsedi;
		}
	#endif
	for(; i < in; i++)
		CurrentNode = LD_VAS_NodePTR(VAS, CurrentNode);
	#if LD_WITCH_VAS_FPS_LASTUSED == 1
		VAS->LastUsedn = CurrentNode;
		VAS->LastUsedi = i;
	#endif
	return CurrentNode;
}

LT_VAS_Node F_WITCH_VAS_RunTillHitNode(LT_VAS *VAS, LT_VAS_Node node){
	LT_VAS_Node n = 0, o = 0;
	while(o != node){
		n = o;
		o = LD_VAS_NodePTR(VAS, o);
	}
	return n;
}

LT_VAS_Node F_WITCH_VAS_NodeVAS(LT_VAS *VAS){
	LT_VAS_Node n;
	if(VAS->EmptyNodes.Possible){
		n = VAS->EmptyNodes.Current;
		if(VAS->EmptyNodes.Possible)
			VAS->EmptyNodes.Current = LD_VAS_NodePTR(VAS, VAS->EmptyNodes.Current);
		VAS->EmptyNodes.Possible--;
	}
	else{
		n = VAS->Nodes.Current;
		VAS->Nodes.Current++;
		LDF_HandleAlloc(&VAS->Nodes);
	}
	return n;
}

#define LDF_InVAS_(M_VAS, M_in) LF_InVAS_(M_VAS, M_in)
LT_VAS_Node LF_InVAS_(LT_VAS *VAS, LT_VAS_Node in){
	LT_VAS_Node Node = F_WITCH_VAS_FindNode(VAS, in < LD_VAS_TotalNodes(VAS) ? LD_VAS_TotalNodes(VAS) - 1 : in ? in - 1 : 0);
	LT_VAS_Node oNode;
	while(in >= LD_VAS_TotalNodes(VAS)){
		oNode = Node;
		Node = F_WITCH_VAS_NodeVAS(VAS);
		#if LD_WITCH_VAS_FPS_LASTNODE == 1
			VAS->LastNode = Node;
		#endif
		LD_VAS_NodePTR(VAS, oNode) = Node;
	}
	return Node;
}

#define LDF_InVAS(M_VAS, M_in, M_out) LF_InVAS(M_VAS, M_in, (T_ptr)M_out)
void LF_InVAS(LT_VAS *VAS, LT_VAS_Node in, T_ptr out){
	LT_VAS_Node Node = LF_InVAS_(VAS, in);
	LF_MCOP(out, VAS->OutputSize * 8, LD_VAS_NodeOUT(VAS, Node));
}

#define LDF_VAS_AddNodeNext(M_VAS, M_in) LF_VAS_AddNodeNext(M_VAS, M_in)
LT_VAS_Node LF_VAS_AddNodeNext(LT_VAS *VAS, LT_VAS_Node in){
	LT_VAS_Node LastNode = LD_VAS_LastNode(VAS);
	LT_VAS_Node Node = F_WITCH_VAS_NodeVAS(VAS);
	if(in != LastNode){
		LD_VAS_NodePTR(VAS, Node) = LD_VAS_NodePTR(VAS, in);
		LD_VAS_NodePTR(VAS, in) = Node;
	}
	else{
		LD_VAS_NodePTR(VAS, in) = Node;
		#if LD_WITCH_VAS_FPS_LASTNODE == 1
			VAS->LastNode = Node;
		#endif
	}
	#if LD_WITCH_VAS_FPS_LASTUSED == 1
		VAS->LastUsedi = 0;
		VAS->LastUsedn = 0;
	#endif
	return Node;
}

#define LDF_VAS_AddNodeBack(M_VAS, M_in) \
	T_ui MV_LDF_VAS_AddNodeBack_round = 0; \
	LT_VAS_Node MV_Node = F_WITCH_VAS_NodeVAS(M_VAS); \
	while(LF_VAS_AddNodeBack(M_VAS, M_in, MV_Node, &MV_LDF_VAS_AddNodeBack_round))
T_ui LF_VAS_AddNodeBack(LT_VAS *VAS, LT_VAS_Node in, LT_VAS_Node Node, T_ui *round){
	if(!*round){
		(*round)++;
		return 1;
	}
	#if LD_WITCH_VAS_FPS_LASTNODE == 1
		if(in == LD_VAS_LastNode(VAS))
			VAS->LastNode = Node;
	#endif
	LDF_MCOP(LD_VAS_NodeOUT(VAS, in), VAS->OutputSize * 8, LD_VAS_NodeOUT(VAS, Node));
	LD_VAS_NodePTR(VAS, Node) = LD_VAS_NodePTR(VAS, in);
	LD_VAS_NodePTR(VAS, in) = Node;
	#if LD_WITCH_VAS_FPS_LASTUSED == 1
		VAS->LastUsedi = 0;
		VAS->LastUsedn = 0;
	#endif
	return 0;
}

#define LDF_OutVAS(M_VAS, M_in) LF_OutVAS(M_VAS, M_in)
T_ptr LF_OutVAS(LT_VAS *VAS, LT_VAS_Node in){
	if(in >= LD_VAS_TotalNodes(VAS))
		return 0;
	LT_VAS_Node x = F_WITCH_VAS_FindNode(VAS, in);
	return LD_VAS_NodeOUT(VAS, x);
}

#define LDF_VAS_rm_node(M_VAS, M_in) \
	T_ui MV_LDF_VAS_AddNodeBack_round = 0; \
	LT_VAS_Node MV_Node; \
	while(LF_VAS_rm_node(M_VAS, M_in, &MV_Node, &MV_LDF_VAS_AddNodeBack_round))
T_ui LF_VAS_rm_node(LT_VAS *VAS, LT_VAS_Node node, LT_VAS_Node *moved, T_ui *round){
	if(node != LD_VAS_LastNode(VAS)){
		if(!*round){
			(*round)++;
			*moved = LD_VAS_NodePTR(VAS, node);
			return 1;
		}
		#if LD_WITCH_VAS_FPS_LASTNODE == 1
			if(*moved == LD_VAS_LastNode(VAS))
				VAS->LastNode = node;
		#endif
		LDF_MCOP(&LD_VAS_NodePTR(VAS, *moved), LD_VAS_NodeSize(VAS) * 8, &LD_VAS_NodePTR(VAS, node));
	}
	else{
		*moved = node;
		#if LD_WITCH_VAS_FPS_LASTNODE == 1
			VAS->LastNode = F_WITCH_VAS_RunTillHitNode(VAS, node);
		#endif
	}
	LD_VAS_NodePTR(VAS, *moved) = VAS->EmptyNodes.Current;
	VAS->EmptyNodes.Current = *moved;
	VAS->EmptyNodes.Possible++;
	#if LD_WITCH_VAS_FPS_LASTUSED == 1
		VAS->LastUsedi = 0;
		VAS->LastUsedn = 0;
	#endif
	return 0;
}

#endif
