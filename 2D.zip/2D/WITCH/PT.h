///* Process y Thread */
//
//#ifndef WITCH_PT
//#define WITCH_PT
//
//#include <WITCH/Types.h>
//#include <WITCH/Alloc.h>
//#include <WITCH/Math.h>
//
//#ifdef _WIN32
//	#include <windows.h>
//#endif
//
//void LF_ProcessExit(int num){
//	exit(num);
//}
//
//void LF_sleepf(T_f time){
//	#ifdef _WIN32
//		HANDLE timer;
//		LARGE_INTEGER li;
//		if(!(timer = CreateWaitableTimer(NULL, TRUE, NULL)))
//			return;
//		li.QuadPart = -(time * 100000000);
//		if(!SetWaitableTimer(timer, &li, 0, NULL, NULL, FALSE)){
//			CloseHandle(timer);
//			return;
//		}
//		WaitForSingleObject(timer, INFINITE);
//		CloseHandle(timer);
//	#else
//		struct timespec t;
//		t.tv_sec = LDF_floor(time);
//		t.tv_nsec = LDF_fmod(time, 1) * 1000000000;
//		nanosleep(&t, &t);
//	#endif
//}
//
//void LF_sleepi(T_uid time){
//	#ifdef _WIN32
//		HANDLE timer;
//		LARGE_INTEGER li;
//		if(!(timer = CreateWaitableTimer(NULL, TRUE, NULL)))
//			return;
//		li.QuadPart = -(time * 100000000);
//		if(!SetWaitableTimer(timer, &li, 0, NULL, NULL, FALSE)){
//			CloseHandle(timer);
//			return;
//		}
//		WaitForSingleObject(timer, INFINITE);
//		CloseHandle(timer);
//	#else
//		struct timespec t;
//		t.tv_sec = time / 1000000000;
//		t.tv_nsec = time % 1000000000;
//		nanosleep(&t, &t);
//	#endif
//}
//
//#ifndef _WIN32
//	#include <unistd.h>
//	#ifdef LD_WITCH_PT_IS_PROCESS_MULTITHREAD
//		#include <pthread.h>
//	#endif
//#endif
//
//#define LDF_PT_RUN_nonflow(M_alloc, M_path, ...)do{ \
//	(M_alloc)->Current = 0; \
//	int link_d[2]; \
//	pid_t pid_d; \
//	char foo_d[2]; \
//	if(pipe(link_d) == -1) \
//		break; \
//	if((pid_d = fork()) == -1) \
//		break; \
//	if(pid_d == 0){ \
//		dup2(link_d[1], STDOUT_FILENO); \
//		dup2(link_d[1], STDERR_FILENO); \
//		close(link_d[0]); \
//		close(link_d[1]); \
//		execl(M_path, M_path, ##__VA_ARGS__, 0); \
//		LF_ProcessExit(0); \
//	} \
//	else{ \
//		close(link_d[1]); \
//		char out_d; \
//		while(read(link_d[0], &out_d, 1) > 0) \
//			LDF_iAllocAdd(M_alloc, char, out_d); \
//	} \
//}while(0);
//
//#define LDF_PT_OpenThread(M_function, ...) \
//	LF_PT_OpenThread((void *)(M_function), (void *)(0, ##__VA_ARGS__));
//
//pthread_t LF_PT_OpenThread(void *f, void *p){
//	pthread_t pid;
//	pthread_create(&pid, 0, f, p);
//	return pid;
//}
//
//#endif
