#ifndef WITCH_Alloc
#define WITCH_Alloc

#include <stdlib.h>
#include <WITCH/Types.h>
#include <WITCH/PT.h>

#define D_WITCH_Alloc_MaxTryForResize 1024

typedef T_ui(*LTF_AllocFail)(T_ptr);

T_ui F_WITCH_Alloc_AllocFail(T_ptr ptr){
	//LF_ProcessExit(-0);
	return 0;
}

typedef struct{
	T_ui Current, Possible, Type, Buffer;
	T_ptr ptr;
	LTF_AllocFail AllocFail;
}LT_Alloc;
#define LDC_Alloc(M_typeSize) (LDC_WITCH(LT_Alloc){0, 0, M_typeSize, 1024, 0, F_WITCH_Alloc_AllocFail})

#define LDF_ResizePointer(M_ptr, M_size) (T_ptr)(M_ptr ? realloc(M_ptr, M_size) : malloc(M_size))

#define LDF_DebugResize(M_ptr, M_size) LF_DebugResize((T_ptr)M_ptr, M_size, F_WITCH_Alloc_AllocFail)
#define LDF0_DebugResize(M_ptr, M_size, M_AllocFail) LF_DebugResize((T_ptr)M_ptr, M_size, M_AllocFail)
T_ptr LF_DebugResize(T_ptr ptr, T_ui size, LTF_AllocFail AllocFail){
	T_ptr z;
	T_ui w = 0;
GT_Resize:
	z = ptr;
	ptr = LDF_ResizePointer(ptr, size);
	if(!ptr){
		ptr = z;
		w++;
		if(w == D_WITCH_Alloc_MaxTryForResize)
			if(!AllocFail(z))
				return ptr;
		goto GT_Resize;
	}
	return ptr;
}

#define LDF0_HandleAlloc(M_Alloc, M_Element) {(M_Alloc)->Current += M_Element; LDF_HandleAlloc(M_Alloc);}
#define LDF_HandleAlloc(M_Alloc) {if((M_Alloc)->Current >= (M_Alloc)->Possible) LF_HandleAlloc((LT_Alloc *)M_Alloc);}
void LF_HandleAlloc(LT_Alloc *Alloc){
	Alloc->Possible = Alloc->Current + ((Alloc->Buffer / Alloc->Type) > 0 ? (Alloc->Buffer / Alloc->Type) : 1);
	Alloc->ptr = LDF0_DebugResize(Alloc->ptr, Alloc->Possible * Alloc->Type, Alloc->AllocFail);
}

#define LDF_iAllocAdd(M_Alloc, M_type, M_in) {LDF_HandleAlloc(M_Alloc); ((M_type *)(M_Alloc)->ptr)[(M_Alloc)->Current] = M_in; (M_Alloc)->Current++;}

#define LDF_FreePTR(M_ptr) LF_FreePTR((T_ptr)M_ptr)
void LF_FreePTR(T_ptr ptr){
	free(ptr);
}

#define LDF_FreeAlloc(M_Alloc) LF_FreeAlloc((LT_Alloc *)M_Alloc)
void LF_FreeAlloc(LT_Alloc *Alloc){
	LF_FreePTR(Alloc->ptr);
	Alloc->Current = 0;
	Alloc->Possible = 0;
	Alloc->ptr = 0;
}

#endif
